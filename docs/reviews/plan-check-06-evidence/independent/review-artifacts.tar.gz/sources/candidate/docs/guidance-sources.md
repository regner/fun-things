# Guidance sources and adaptation

The reusable guidance comes from the sibling Godot project
`~/Development/vcs`, reviewed on 7 October 2026. This checkout retains working
conventions and lessons that apply beyond VCS's vehicle combat game. It does not
depend on the sibling checkout at runtime or require its tooling to exist here.

## Source coverage

| VCS sources | Reusable guidance | Destination |
| --- | --- | --- |
| `AGENTS.md`, `README.md` | MCP-first editing, simplicity, ownership, style, saved identities, layered checks | `AGENTS.md`, development guide |
| `mise.toml`, `gdstyle.toml`, `.github/workflows/gdscript.yml`, compiler/style/resource tooling | Pinned dependencies, owned/vendor scope, all-script checks, resource integrity, matching local/CI tasks | Development guide |
| `docs/project-review.md` | Exact input types, shared formulas/IDs, restored telemetry, observer ordering, independent regression expectations, honest check limits | Repository and multiplayer guidance |
| `docs/art-pipeline.md`, pipeline audit/inventory | Saved-source ownership, import ancestry, scene placement authority, compact resources, source/export consistency, clean export contents | Asset and development guides |
| `docs/valley-level-design.md`, asset production/integration, playtest records | Measured dimensions, origins, collision contracts, real actor/camera checks, material conventions, profiling limits, explicit integration ownership | Asset guide |
| `docs/beauty-review/astra-review.md` | Comparable review cameras, visual hierarchy, preserve gameplay envelopes, distinguish screenshot evidence from runtime behavior | Asset guide |
| `docs/multiplayer-first-pass.md`, `docs/client-prediction-plan.md` | Session/match boundaries, admission, stale state, input bounds, simulation acknowledgement, replay, host-stall recovery, real-process tests | Multiplayer guide |
| `docs/destructible-environments.md`, `docs/street-props.md` | Stable world IDs, persistent baselines, deferred collision revisions, cosmetic effects, prediction limits | Asset and multiplayer guides |
| `docs/weapons-first-pass.md`, `art/audio/README.md` | Controller-independent APIs, atomic replacement, reliable equipment, projectile events, lifecycle cancellation, feedback ownership, licenses, bounded voices | All three guides |
| `docs/steam-private-testing.md`, release/version sections of `README.md` | Matching templates, complete exports, packaged revision, platform testing, separate upload/activation/installation stages | Development and multiplayer guides |
| `TODO.md` | Keep tasks actionable; completed work leaves the active list; outstanding gameplay issues are evidence for acceptance cases | Repository guidance |

Bundled addon manuals describe the addon rather than general project policy.
Use the installed toolkit's own documentation when operating it; upstream addon
formatting and lifecycle behavior remain separate from project-owned code.

## Adaptation decisions

- Preserve editor synchronization, single ownership, shared simulation rules,
  meaningful identities, bounded networking, and evidence-based validation.
- Generalize scene paths, components, naming, spawn policy, collision masks, and
  gameplay examples. The [P0-02 architecture](architecture.md) now supplies the
  concrete draft ownership map for this project's proofs.
- Require ENet for local testing and Steam for friends playtesting on this project's
  existing app. Choose/pin the Steam integration through a technical proof; keep
  provider details behind the shared session boundary. P0-01 selected an authoritative
  listen server for 1–4 players; dedicated servers and host migration remain deferred.
  Prediction needs feel/network evidence; car destruction is required by the product.
- Keep VCS's rates, player capacity, payload limits, and replay sizes as examples.
  They do not establish this project's performance or protocol requirements.
- Require Blender-authored visible 3D models and linked explicit exports, including
  blockouts and spike fixtures, following Fun Things' product requirements. This
  supersedes the initial adaptation that allowed primitive/procedural render meshes.
  Collision, navigation, occlusion data, and debug overlays remain separate.
- Retain documented style and manual review. The existing gdstyle configuration
  does not include VCS's custom spacing/documentation wrapper or its smoke tests.
- Current foundation tooling is accepted at fixture scope through
  [S01 resource/source evidence](spikes/s01.md#evidence-and-reproduction) and
  [combined P0-03/S03 acceptance](spikes/s03.md#integration-validation).
  `mise run gdstyle:check` checks pinned formatting/lint; `gdscript:check` explicitly
  compiles every discovered owned script, including unused scripts, in a fresh
  dependency mirror. `resources:check`, `s01:clean` and `s01:reexport` validate the
  focused S01 resource/source/identity workflow; `spike:s03` runs the bounded
  two-process ENet fixture and `tools:check` checks runner/discovery behavior.
  These are implemented tasks in `mise.toml` and `tools/`, not copied VCS names.
  Manual purpose-comment/spacing review remains required. CI, a preserving formatter
  wrapper and broader production asset/gameplay/network coverage remain M1-D1 work;
  focused success does not certify full-project plugin diagnostics, Steam or Deck.
- The user requires completed tasks to be removed from `TODO.md` and committed
  together with their resolving changes. This supersedes the earlier adaptation
  that left automatic TODO commits optional. Do not copy VCS's version-bump/tag
  side effects.
- Omit VCS assets, maps, exact gameplay tuning, credentials, measured benchmark
  results and unrelated project-specific defects. During P0-01 the user explicitly
  designated VCS's existing Steam AppID/depot IDs for Fun Things; [the brief](design.md)
  records those IDs and distinguishes repo recipes from verified live settings.
  This supersedes the earlier blanket exclusion of Steam identities. Branch/launch
  choices remain project decisions; no VCS delivery configuration was changed.

Some VCS documents retain superseded plans: old engine pins, targets later removed,
initial no-prediction behavior, earlier admission/interpolation designs, and retired
level rebuild utilities. Current ownership and implemented follow-ups take precedence
over those historical sections. New guidance avoids treating either historical
checkpoints or VCS's acceptance results as implemented behavior here.

## Primary documentation

Godot API and import details were checked against official documentation. This
project pins a development engine, so verify exact API behavior against that engine
when implementing; stable documentation is a baseline rather than the version pin.

- [Godot high-level multiplayer](https://docs.godotengine.org/en/stable/tutorials/networking/high_level_multiplayer.html)
- [Godot MultiplayerSynchronizer](https://docs.godotengine.org/en/stable/classes/class_multiplayersynchronizer.html)
- [Godot version control guidance](https://docs.godotengine.org/en/stable/tutorials/best_practices/version_control_systems.html)
- [Godot 3D import formats](https://docs.godotengine.org/en/stable/tutorials/assets_pipeline/importing_3d_scenes/available_formats.html)
- [Valve Steam Datagram Relay](https://partner.steamgames.com/doc/features/multiplayer/steamdatagramrelay)
