"""Capture actual packaging stdout/stderr and bind all delivery sidecars."""
from pathlib import Path
import hashlib,json,subprocess

p=Path('/tmp/plan-check06-independent-review')
argv=['python3',str(p/'package_review.py')]
r=subprocess.run(argv,capture_output=True,timeout=30)
(p/'raw/package.stdout').write_bytes(r.stdout)
(p/'raw/package.stderr').write_bytes(r.stderr)
(p/'raw/package.command.json').write_text(json.dumps({'argv':argv,'returncode':r.returncode},indent=2)+'\n')
assert r.returncode==0
rows=[]
for f in sorted(p.rglob('*')):
    if not f.is_file() or f.name in {'delivery-ledger.json','SHA256SUMS'}:continue
    raw=f.read_bytes();rows.append({'path':f.relative_to(p).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(p/'delivery-ledger.json').write_text(json.dumps({'candidate':'6b4a69e43cd8cebb5535f77a54da162d33630ab1','files':rows},indent=2)+'\n')
(p/'SHA256SUMS').write_text(''.join(row['sha256']+'  '+row['path']+'\n' for row in rows)+hashlib.sha256((p/'delivery-ledger.json').read_bytes()).hexdigest()+'  delivery-ledger.json\n')
print(r.stdout.decode(),end='')
