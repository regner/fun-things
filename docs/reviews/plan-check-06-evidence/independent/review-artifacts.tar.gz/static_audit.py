"""Independent immutable checkpoint audit. Static reads; all output stays in /tmp."""
from pathlib import Path
import ast, base64, gzip, hashlib, io, json, re, subprocess, tarfile, unicodedata
from urllib.parse import unquote, urlsplit

OUT = Path('/tmp/plan-check06-independent-review')
BASE = '754a0b501fe705c93675ff09b43d5bfca201cd94'
CANDIDATE = '6b4a69e43cd8cebb5535f77a54da162d33630ab1'
PRIOR = 'ca38e4fc55b32a379ef7e3bf947e27d4ca8edc4c'
PREFIX = 'docs/reviews/plan-check-06-evidence/'
SEQUENCE = ['cd01975a96140c5a8e9e686352dddb6c6a249ac1',
 'a509ca99d9bfb675b0b31464cd2a03bd001155c1', 'c0eda26f7f010af75bbf10c272ec5cb001442331',
 'e871aa7e46cb9a77f598ebcfe4bcd6dc995bb0a4', 'a6f647e0798f2e458e4f0dcdd033d759e875e6b3',
 'c8096b55ef97412552366fdaa74c220b976ed82e', '50406d0b7931c409f76bc114018be8379300e8ba',
 'f7883c332a3728267afc86343d6e0f8dc696ede6', '8ade585120a20edfea4a8bf5f7ac1698bc0c7883', BASE]
TASKS = ['P0-PROFILES','S02','S03-S','S03-R','S04','S05','S06','S07','S08','P0-GATE',
 'M1-A1','M1-A2','M1-A3','M1-A-GATE','M1-B1','M1-B2','M1-B3','M1-B4',
 'M1-C1','M1-C2','M1-C3','M1-C4','M1-D1','M1-D2','M1-D3','M1-D4','M1-GATE']

def run(name, argv, allowed=(0,)):
    r = subprocess.run(argv, capture_output=True, timeout=60)
    (OUT/'raw'/f'{name}.stdout').write_bytes(r.stdout)
    (OUT/'raw'/f'{name}.stderr').write_bytes(r.stderr)
    (OUT/'raw'/f'{name}.command.json').write_text(json.dumps(
        {'argv':argv,'returncode':r.returncode},indent=2)+'\n')
    assert r.returncode in allowed, (name,r.returncode,r.stderr.decode())
    return r.stdout

def git(*argv):
    return subprocess.check_output(['git',*argv],timeout=60)

def blob(path, rev=CANDIDATE):
    return git('show',f'{rev}:{path}')

def identity(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def pairs(rows):
    d={}
    for k,v in rows:
        assert k not in d, k
        d[k]=v
    return d

def parse(raw):
    return json.loads(raw,object_pairs_hook=pairs)

def archive(raw):
    files={}
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
        for m in t.getmembers():
            if m.isdir(): continue
            assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
            assert m.name not in files
            files[m.name]=t.extractfile(m).read()
    return files

def verify(raw, row, size='bytes', sha='sha256'):
    assert len(raw)==row[size] and hashlib.sha256(raw).hexdigest()==row[sha], row

def save_report(name,raw):
    p=OUT/'accepted-reports'/name; p.parent.mkdir(exist_ok=True);p.write_bytes(raw)

def blocks(raw):
    text=raw.decode(); matches=list(re.finditer(r'^- \[ \] \*\*([A-Z0-9-]+) —',text,re.M))
    result={}
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(text)
        v=re.split(r'(?m)^#{1,3} ',text[m.start():end],maxsplit=1)[0].rstrip()
        assert m[1] not in result
        result[m[1]]=v
    return result

def tree(rev):
    return {entry.split(b'\t',1)[1].decode():entry.split(b'\t',1)[0].decode()
            for entry in git('ls-tree','-rz',rev).split(b'\0') if entry}

def slugs(raw):
    text=re.sub(r'(?ms)^```.*?^```[^\n]*\n?','',raw.decode()); counts={}; ids=set()
    for line in text.splitlines():
        m=re.match(r'^#{1,6}\s+(.+?)\s*#*$',line)
        if not m:continue
        title=re.sub(r'[`*_]','',m[1]).lower()
        slug=''.join(c for c in title if c in '-_ ' or unicodedata.category(c)[0] in 'LN').replace(' ','-')
        n=counts.get(slug,0);counts[slug]=n+1;ids.add(slug+(f'-{n}' if n else ''))
    return ids

def main():
    assert git('rev-parse','HEAD').decode().strip()==CANDIDATE
    assert git('rev-parse','refs/heads/main').decode().strip()==BASE
    assert git('rev-parse','--abbrev-ref','HEAD').decode().strip()=='plan-checkpoint-explosion-chain'
    assert not run('start-clean',['git','status','--porcelain=v1','--untracked-files=all']).strip()
    actual=git('rev-list','--reverse',f'{PRIOR}..{BASE}').decode().splitlines()
    assert actual==SEQUENCE
    last=PRIOR; history=[]
    manifest=parse(blob(PREFIX+'audit-manifest.json'))
    assert manifest['accepted_commit_count']==10
    for i,rev in enumerate(actual):
        assert git('show','-s','--format=%P',rev).decode().strip()==last
        paths=git('diff-tree','--no-commit-id','--name-only','-r',rev).decode().splitlines()
        me=manifest['commits'][i]; assert me['revision']==rev and me['parents']==[last] and me['paths']==paths
        # All complete path/mode deltas read. Accepted code is scope evidence, not re-audited.
        raw=run(f'history-{i+1:02d}-paths',['git','diff','--raw',last,rev])
        docs=[p for p in paths if p in ['TODO.md','README.md'] or p.endswith('.md') and not '-evidence/' in p]
        docdiff=run(f'history-{i+1:02d}-docs',['git','diff',last,rev,'--',*docs]) if docs else b''
        history.append({'revision':rev,'parent':last,'paths':paths,'raw_delta':identity(raw),'docs_delta':identity(docdiff)})
        last=rev
    for a,b in [(PRIOR,BASE),(BASE,CANDIDATE)]:
        run('ancestry-'+a[:7],['git','merge-base','--is-ancestor',a,b])
    assert not git('rev-list','--merges',f'{PRIOR}..{CANDIDATE}').strip()
    assert git('show','-s','--format=%P',CANDIDATE).decode().strip()==BASE
    for row in manifest['consulted']: verify(blob(row['path']),row)
    verify(blob('TODO.md',BASE),manifest['accepted_base_TODO'])
    print('PASS exact ten accepted commits/parents/paths/consulted immutable hashes; candidate parent/linear ancestry')

    before=blocks(blob('TODO.md',BASE)); after=blocks(blob('TODO.md'))
    assert list(before)==TASKS and len(after)==29 and set(after)-set(before)=={'P0-DOC8','P0-DOC9'}
    changed=[k for k in before if before[k]!=after[k]]
    assert set(changed)=={'P0-PROFILES','S05','S07','P0-GATE'}
    record=blob('docs/reviews/plan-check-2026-10-08-06.md').decode()
    rows=re.findall(r'^\| ([A-Z][A-Z0-9-]+)(?: \(new\))? \|',record,re.M)
    assert len(rows)==len(set(rows))==29 and set(rows)==set(after)
    assert [len(blocks(blob('TODO.md',r))) for r in ['c0eda26','e871aa7','a6f647e',BASE]]==[29,28,27,27]
    for task in ['P0-DOC8','P0-DOC9']:
        assert all(s in after[task] for s in ['Owner role:','Files:','Prerequisites:','Evidence:','Done when:','Remove','P0-GATE'])
    ta=tree(BASE);tb=tree(CANDIDATE)
    changed_paths={p for p in set(ta)|set(tb) if ta.get(p)!=tb.get(p)}
    assert len(changed_paths)==22
    assert all(p in ['TODO.md','docs/reviews/plan-checkpoints.md','docs/reviews/plan-check-2026-10-08-06.md'] or p.startswith(PREFIX) for p in changed_paths)
    preserved=[]
    for p,metadata in ta.items():
        if p in changed_paths:continue
        assert tb[p]==metadata
        raw=blob(p,BASE); assert Path(p).read_bytes()==raw
        assert bool(Path(p).stat().st_mode&0o111)==(metadata.split()[0]=='100755')
        preserved.append({'path':p,'mode_blob':metadata,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
    assert len(preserved)==1792
    print('PASS full27 to29 task IDs/order/counts/four revised blocks;1792 preserved mode/blob/working entries')

    jsons=[];links=[];authored=[];compressed=[]
    for p in sorted(changed_paths):
        raw=blob(p)
        assert tb[p].split()[0]=='100644'
        if p.endswith('.gz'):
            decoded=gzip.decompress(raw); compressed.append({'path':p,'stored':identity(raw),'raw':identity(decoded)})
            continue
        assert b'\r' not in raw and raw.endswith(b'\n') and not raw.endswith(b'\n\n')
        assert not re.search(rb'[ \t]+\n',raw),p
        if p.endswith('.json'): parse(raw);jsons.append(p)
        if p.endswith('.py'): ast.parse(raw)
        if p.endswith('.md'):
            for m in re.finditer(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',raw.decode()):
                ref=unquote(m[1].strip('<>')); u=urlsplit(ref)
                if u.scheme or u.netloc:continue
                target=(Path(p).parent/u.path) if u.path else Path(p)
                target=Path(__import__('os').path.normpath(str(target)))
                assert str(target) in tb,(p,ref,target)
                if u.fragment and target.suffix=='.md':assert u.fragment in slugs(blob(str(target))),(p,ref)
                links.append({'source':p,'ref':ref,'target':str(target),'fragment':u.fragment})
        authored.append({'path':p,**identity(raw)})
    assert len(links)==135
    for row in parse(blob(PREFIX+'worker-retention.json'))['artifacts']:
        stored=blob(PREFIX+row['retained']);verify(stored,row,'stored_bytes','stored_sha256');verify(gzip.decompress(stored),row)
    run('candidate-whitespace',['git','diff','--check',BASE,CANDIDATE])
    raw=run('accepted-whitespace',['git','diff','--check',PRIOR,BASE],(2,))
    exact={'docs/spikes/s05-evidence/raw-s05-todo.md','docs/spikes/s05-evidence/editor/protocol-queue-before-measurement.md'}
    assert set(re.findall(r'(?m)^([^:\n]+):\d+:',raw.decode()))==exact
    run('accepted-whitespace-exact-exclusions',['git','diff','--check',PRIOR,BASE,'--','.',*[':(exclude)'+p for p in sorted(exact)]])
    print('PASS 135 immutable local links/anchors, JSON duplicate keys, AST, authored LF/whitespace, retained raw compressed bytes')

    notes=[]
    for rev,label,start,end,ledgername in [
        ('c0eda26','fifth',b'--- BEGIN BASE64 EXACT-FINAL CHECKPOINT ARTIFACT TAR.GZ ---',b'--- END BASE64 EXACT-FINAL CHECKPOINT ARTIFACT TAR.GZ ---','final-note-artifact-manifest.json'),
        ('c8096b5','doc67',b'--- BEGIN BASE64 LOSSLESS ARTIFACT TAR.GZ ---',b'--- END BASE64 LOSSLESS ARTIFACT TAR.GZ ---','manifest.json')]:
        raw=git('notes','--ref=paseo-orchestration','show',rev)
        encoded=raw.split(start,1)[1].split(end,1)[0]
        packed=base64.b64decode(encoded);files=archive(packed);ledger=parse(files[ledgername])
        rows=ledger['files']; assert len(rows)==(35 if label=='fifth' else 462)
        for row in rows:verify(files[row['path']],row)
        for p,b in files.items():
            if (label=='fifth' and p=='exact-final-report.md') or (label=='doc67' and p in ['reviewer/report.md','reviewer/retention-followup/report.md','worker/final-handoff.json']):
                save_report(label+'-'+p.replace('/','_'),b)
        text=raw.split(start)[0]+raw.split(end)[1]
        save_report(label+'-note-text.txt',text)
        (OUT/f'{label}-payload-ledger.json').write_bytes(files[ledgername])
        notes.append({'revision':rev,'note_blob':git('notes','--ref=paseo-orchestration','list',rev).decode().strip(),'wrapper':identity(raw),'pack':identity(packed),'count':len(rows)})
    note_raw=git('notes','--ref=paseo-orchestration','show',BASE);note=parse(note_raw);assert len(note['artifacts'])==20
    identities=[];decoded={}
    for row in note['artifacts']:
        stored=base64.b64decode(row['data']);verify(stored,row,'stored_bytes','stored_sha256');raw=gzip.decompress(stored);verify(raw,row)
        decoded[row['source_path']]=raw;identities.append({k:v for k,v in row.items() if k!='data'})
    final=decoded['/tmp/s05-independent-final-review/report.md'];assert len(final)==14250
    assert hashlib.sha256(final).hexdigest()=='8b5a709c25134ff7b5d0a8222b46ab94efa69e2292924fe0e4fa79cca23c88c9'
    save_report('s05-final-report.md',final)
    files=archive(decoded['/tmp/s05-independent-final-review/final-review-artifacts.tar.gz'])
    ledger=parse(decoded['/tmp/s05-independent-final-review/final-manifest.json']); rows=ledger.get('entries',ledger.get('files'));assert len(rows)==14
    for row in rows:verify(files[row['path']],row)
    for path,raw in decoded.items():
        if path.endswith('handoff.json'):save_report('s05-'+Path(path).parent.name+'-handoff.json',raw)
    (OUT/'s05-note-artifact-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
    roots=next(x for x in note['root_receipts'] if 'receipt' in x)
    ledger_raw=Path('/tmp/s05-editor-relocation/hash-ledger.json').read_bytes()
    assert hashlib.sha256(ledger_raw).hexdigest()=='cb355f9be4b6a7a2ca38ecd6574ec5d2819e1dd3b7425375fc30e2a7544e6193'
    rootledger=parse(ledger_raw);assert len(rootledger['entries'])==31
    for row in rootledger['entries']:verify((Path('/tmp/s05-editor-relocation')/row['path']).read_bytes(),row)
    for filename,key in [('receipt.json','receipt'),('hash-ledger.json','hash_ledger'),('ledger-verification.json','ledger_verification'),('managed-cwd-references.json','managed_cwd_references')]:
        raw=(Path('/tmp/s05-editor-relocation')/filename).read_bytes();assert parse(raw)==roots[key]
        (OUT/'sources'/('root-'+filename)).write_bytes(raw)
    assert note['handoff']['final_head']==BASE
    save_report('s05-root-metadata.json',json.dumps({k:v for k,v in note.items() if k!='artifacts'},indent=2).encode()+b'\n')
    notes.append({'revision':BASE,'note_blob':git('notes','--ref=paseo-orchestration','list',BASE).decode().strip(),'wrapper':identity(note_raw),'artifacts':20,'final_artifacts':14,'final_report':identity(final),'root_ledger':identity(ledger_raw),'root_count':31})
    # Verify committed S05 bundles and original raw artifacts without rerunning them.
    for row in parse(blob('docs/spikes/s05-evidence/retention.json')):
        raw=blob('docs/spikes/s05-evidence/'+row['path']);verify(raw,row,'stored_bytes','stored_sha256')
        verify(gzip.decompress(raw) if row['gzip'] else raw,row,'raw_bytes','raw_sha256')
    subpack=archive(blob('docs/spikes/s05-evidence/review/review-artifacts.tar.gz'))
    subrows=parse(blob('docs/spikes/s05-evidence/review/review-manifest.json'))['entries'];assert len(subrows)==51
    for row in subrows:verify(subpack[row['path']],row)
    save_report('s05-substantive-report.md',blob('docs/spikes/s05-evidence/review/report.md'))
    print('PASS fifth35/DOC67 462;S05 note20/full14250-byte report/final14/substantive51/raw250;root31 hash ledger')

    discovery=parse(blob(PREFIX+'profile-discovery.json'))
    assert discovery[0]['value']['structuredContent']['profiles']==[]
    models={r['id']:r for r in discovery[2]['value']['structuredContent']['models']}
    for model,effort in [('gpt-6.1-sol','medium'),('gpt-6.1-sol','high'),('gpt-6-luna','high'),('gpt-6-astra','high')]:
        assert effort in {r['id'] for r in models[model]['thinkingOptions']}
    proposals=parse(blob('docs/workflows/p0-profiles-evidence/proposed.patch.json'))
    assert len(proposals['agentProfiles'])==4
    metadata=parse((OUT/'own-metadata.json').read_bytes())['structuredContent']['snapshot']
    assert metadata['id']=='61a98ca5-6288-4923-b0f3-ea7fe21d37c3' and metadata['workspaceId']=='wks_c98e3f48e2b014a8'
    assert metadata['model']=='gpt-6.1-sol' and metadata['thinkingOptionId']==metadata['effectiveThinkingOptionId']=='high'
    assert metadata['currentModeId']==metadata['runtimeInfo']['modeId']=='auto-review'
    print('PASS four inert proposals/zero installed captured metadata and own configured/effective Sol HIGH auto-review')
    for marker in ['MERGE_HEAD','CHERRY_PICK_HEAD','REVERT_HEAD','rebase-merge','rebase-apply','sequencer','BISECT_LOG','index.lock']:
        assert not Path(git('rev-parse','--git-path',marker).decode().strip()).exists(),marker
    assert not run('final-clean',['git','status','--porcelain=v1','--untracked-files=all']).strip()
    assert git('rev-parse','HEAD').decode().strip()==CANDIDATE and git('rev-parse','refs/heads/main').decode().strip()==BASE
    result={'candidate':CANDIDATE,'base':BASE,'prior_exclusive':PRIOR,'history':history,'tasks':TASKS,'changed_tasks':changed,'new_tasks':['P0-DOC8','P0-DOC9'],'preserved_entries':preserved,'authored':authored,'json':jsons,'links':links,'compressed':compressed,'notes':notes,'no_active_git_operations':True,'verdict':'static checks pass; substantive disposition separately in report'}
    (OUT/'static-audit-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS frozen candidate/held main clean including untracked;no Git operations;all owned static children completed')

if __name__=='__main__':main()
