"""Capture independent audit stdout/stderr and command identity without normalization."""
from pathlib import Path
import json, subprocess

p=Path('/tmp/plan-check06-independent-review')
argv=['python3',str(p/'static_audit.py')]
r=subprocess.run(argv,capture_output=True,timeout=180)
(p/'raw/static-audit.stdout').write_bytes(r.stdout)
(p/'raw/static-audit.stderr').write_bytes(r.stderr)
(p/'raw/static-audit.command.json').write_text(json.dumps({'argv':argv,'returncode':r.returncode},indent=2)+'\n')
print('exit',r.returncode)
print(r.stdout.decode())
print(r.stderr.decode())
