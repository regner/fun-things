"""Losslessly package the sole review, then verify members and make delivery ledgers."""
from pathlib import Path
import hashlib, io, json, subprocess, tarfile

ROOT=Path('/tmp/plan-check06-independent-review')
CANDIDATE='6b4a69e43cd8cebb5535f77a54da162d33630ab1'
BASE='754a0b501fe705c93675ff09b43d5bfca201cd94'

def identity(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def main():
    refs=subprocess.run(['git','rev-parse','HEAD','refs/heads/main'],capture_output=True)
    status=subprocess.run(['git','status','--porcelain=v1','--untracked-files=all'],capture_output=True)
    (ROOT/'raw/delivery-refs.stdout').write_bytes(refs.stdout)
    (ROOT/'raw/delivery-refs.stderr').write_bytes(refs.stderr)
    (ROOT/'raw/delivery-status.stdout').write_bytes(status.stdout)
    (ROOT/'raw/delivery-status.stderr').write_bytes(status.stderr)
    assert refs.returncode==status.returncode==0
    assert refs.stdout.decode().splitlines()==[CANDIDATE,BASE] and not status.stdout
    handoff={'reviewer_id':'61a98ca5-6288-4923-b0f3-ea7fe21d37c3',
      'model':'gpt-6.1-sol','configured_effort':'high','effective_effort':'high','mode':'auto-review',
      'workspace':'wks_c98e3f48e2b014a8','branch':'plan-checkpoint-explosion-chain',
      'candidate':CANDIDATE,'base':BASE,'prior_exclusive':'ca38e4fc55b32a379ef7e3bf947e27d4ca8edc4c',
      'accepted_commits':10,'base_tasks':27,'delivered_tasks':29,'new_tasks':['P0-DOC8','P0-DOC9'],
      'verdict':'ACCEPT substantive checkpoint at exact candidate; one nonblocking P3 units correction before final delivery',
      'findings':[{'severity':'P3','locations':['docs/reviews/plan-check-2026-10-08-06.md:112','TODO.md:797'],
      'contract':'Checkpoint factual reconciliation; accurate evidence reporting in AGENTS.md',
      'observation':'1794 is tracked_files_each_checkout, not a byte count',
      'fix':'Describe preserved bytes of all 1,794 tracked files per checkout; leave raw inputs unchanged'}],
      'check_results':{'candidate_checker_exit':0,'independent_final_exit':0,'immutable_local_links':135,
                      'preserved_mode_blob_working_entries':1792,'candidate_whitespace_exit':0,
                      'accepted_whitespace_exit':2,'exact_two_historical_exclusions_exit':0},
      'limits':'Static only; no technical/runtime/engine/device/profile/service experiment or S05 surface/PID/worktree query',
      'saved':True,'owned_static_children_completed':True,'owned_runtime_or_shared_lease':False,
      'candidate_clean_including_untracked':True,'held_main_unchanged':True,'no_candidate_or_git_mutation':True,
      'report':{'path':str(ROOT/'report.md'),**identity((ROOT/'report.md').read_bytes())},
      'followup':'Same reviewer must explicitly dispose exact new FINAL after correction/retention/rebase',
      'notification':'Return all accessible evidence paths in final response through existing notifyOnFinish callback; no new message/agent'}
    (ROOT/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
    exclude={'manifest.json','review-artifacts.tar.gz','package-verification.json','delivery-ledger.json','SHA256SUMS'}
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p.relative_to(ROOT).as_posix() not in exclude)
    rows=[{'path':p.relative_to(ROOT).as_posix(),**identity(p.read_bytes())} for p in files]
    manifest={'candidate':CANDIDATE,'base':BASE,'reviewer_id':handoff['reviewer_id'],'files':rows}
    (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with tarfile.open(ROOT/'review-artifacts.tar.gz','w:gz') as tar:
        for p in files+[ROOT/'manifest.json']:
            raw=p.read_bytes();m=tarfile.TarInfo(p.relative_to(ROOT).as_posix());m.size=len(raw);m.mode=0o644
            tar.addfile(m,io.BytesIO(raw))
    with tarfile.open(ROOT/'review-artifacts.tar.gz','r:gz') as tar:
        members={m.name:tar.extractfile(m).read() for m in tar.getmembers()}
        assert set(members)=={r['path'] for r in rows}|{'manifest.json'}
        assert members['manifest.json']==(ROOT/'manifest.json').read_bytes()
        for r in rows:
            assert identity(members[r['path']])=={k:r[k] for k in ['bytes','sha256']}
            assert members[r['path']]==(ROOT/r['path']).read_bytes()
    verification={'ok':True,'files':len(rows),'all_complete_sources_raw_outputs_reports_receipts_handoff_match':True,
                  'manifest':identity((ROOT/'manifest.json').read_bytes()),
                  'pack':identity((ROOT/'review-artifacts.tar.gz').read_bytes())}
    (ROOT/'package-verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    delivery=[{'path':p.relative_to(ROOT).as_posix(),**identity(p.read_bytes())}
              for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name not in {'delivery-ledger.json','SHA256SUMS'}]
    (ROOT/'delivery-ledger.json').write_text(json.dumps({'candidate':CANDIDATE,'files':delivery},indent=2)+'\n')
    (ROOT/'SHA256SUMS').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in delivery)+
                                hashlib.sha256((ROOT/'delivery-ledger.json').read_bytes()).hexdigest()+'  delivery-ledger.json\n')
    print(json.dumps({'report':handoff['report'],'manifest':verification['manifest'],
                      'pack':verification['pack'],'files':len(rows),'all_owned_children_complete':True},indent=2))

if __name__=='__main__':main()
