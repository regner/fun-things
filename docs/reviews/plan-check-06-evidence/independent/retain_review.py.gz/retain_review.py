"""Retain the original complete review package and verify every source/stored byte."""
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path.cwd()
source = Path('/tmp/plan-check06-independent-review')
evidence = root / 'docs/reviews/plan-check-06-evidence'
target = evidence / 'independent'
target.mkdir(exist_ok=True)

def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

packed = (source / 'review-artifacts.tar.gz').read_bytes()
with tarfile.open(fileobj=io.BytesIO(packed), mode='r:gz') as pack:
    files = {}
    for member in pack.getmembers():
        assert member.isfile() and not Path(member.name).is_absolute()
        assert '..' not in Path(member.name).parts and member.name not in files
        files[member.name] = pack.extractfile(member).read()
manifest = json.loads((source / 'manifest.json').read_bytes())
assert len(manifest['files']) == 215
assert files['manifest.json'] == (source / 'manifest.json').read_bytes()
assert set(files) == {e['path'] for e in manifest['files']} | {'manifest.json'}
for entry in manifest['files']:
    assert files[entry['path']] == (source / entry['path']).read_bytes()
    assert identity(files[entry['path']]) == {k: entry[k] for k in ['bytes', 'sha256']}
ledger = json.loads((source / 'delivery-ledger.json').read_bytes())
assert len(ledger['files']) == 221
for entry in ledger['files']:
    assert identity((source / entry['path']).read_bytes()) == {k: entry[k] for k in ['bytes', 'sha256']}
report = source / 'report.md'
retained_report = root / 'docs/reviews/plan-check-review-2026-10-08-06.md'
retained_report.write_bytes(report.read_bytes())
artifacts = []
for name in ['review-artifacts.tar.gz', 'manifest.json', 'delivery-ledger.json',
             'package-verification.json', 'SHA256SUMS', 'raw/package.command.json',
             'raw/package.stdout', 'raw/package.stderr']:
    raw = (source / name).read_bytes()
    compressed = name != 'review-artifacts.tar.gz'
    path = target / (name.replace('/', '-') + ('.gz' if compressed else ''))
    stored = gzip.compress(raw, mtime=0) if compressed else raw
    path.write_bytes(stored)
    assert (gzip.decompress(path.read_bytes()) if compressed else path.read_bytes()) == raw
    artifacts.append({'source_path': str(source / name), 'retained': str(path.relative_to(evidence)),
                      'gzip': compressed, **identity(raw), 'stored_bytes': len(stored),
                      'stored_sha256': identity(stored)['sha256']})
for name in ['reviewer-launch-prompt.txt', 'reviewer-launch.json', 'retain_review.py']:
    origin = Path('/tmp/checkpoint06') / name
    raw = origin.read_bytes()
    path = target / (name + '.gz')
    stored = gzip.compress(raw, mtime=0)
    path.write_bytes(stored)
    artifacts.append({'source_path': str(origin), 'retained': str(path.relative_to(evidence)),
                      'gzip': True, **identity(raw), 'stored_bytes': len(stored),
                      'stored_sha256': identity(stored)['sha256']})
receipt = {'candidate': manifest['candidate'], 'base': manifest['base'],
           'reviewer_id': manifest['reviewer_id'], 'model': 'gpt-6.1-sol',
           'configured_effective_effort': 'high', 'mode': 'auto-review',
           'collaboration_mode': 'Default', 'complete_report': {
               'source_path': str(report), 'retained': str(retained_report.relative_to(root)),
               **identity(report.read_bytes())}, 'packed_artifacts': 215,
           'delivery_artifacts': 221, 'all_original_and_stored_bytes_verified': True,
           'artifacts': artifacts,
           'display_read_limitations': [
               {'attempted_path': '/tmp/plan-check06-independent-review/pack-verification.json',
                'observed_stderr': 'cat: /tmp/plan-check06-independent-review/pack-verification.json: No such file or directory',
                'scope': 'scratch display read; correct actual name package-verification.json'},
               {'attempted_path': '/tmp/plan-check06-independent-review/artifact-manifest.json',
                'observed_stderr': "head: cannot open '/tmp/plan-check06-independent-review/artifact-manifest.json' for reading: No such file or directory",
                'scope': 'scratch display read; correct actual name manifest.json; large concatenated output truncated, complete bytes subsequently verified'}]}
(evidence / 'independent-retention.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS complete report and original215 packed/221 delivered artifacts; exact original/stored bytes and hashes')
