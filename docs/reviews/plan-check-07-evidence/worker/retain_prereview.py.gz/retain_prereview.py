import pathlib,json,gzip,hashlib
source=pathlib.Path('/tmp/plan-check07-worker')
destination=pathlib.Path('docs/reviews/plan-check-07-evidence/worker')
destination.mkdir(exist_ok=True)
ledger=[]
for p in sorted(source.iterdir()):
 if not p.is_file():continue
 raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);out=destination/(p.name+'.gz');out.write_bytes(packed)
 assert gzip.decompress(out.read_bytes())==raw
 ledger.append({'source_path':str(p),'artifact':str(out),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'codec':'gzip(raw); mtime=0','stored_bytes':len(packed),'stored_sha256':hashlib.sha256(packed).hexdigest()})
pathlib.Path('docs/reviews/plan-check-07-evidence/worker-retention.json').write_text(json.dumps({'entries':ledger,'expected_source_paths':[e['source_path'] for e in ledger],'self_reference':'packing script included; manifest/output outside input root'},indent=2)+'\n')
print('retained',len(ledger),'new worker artifacts; full readback PASS')
