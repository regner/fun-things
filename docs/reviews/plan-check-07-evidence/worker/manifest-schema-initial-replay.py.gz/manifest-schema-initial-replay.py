import json
for path in ['docs/spikes/s06-evidence/manifest.json','docs/spikes/s06-evidence/review/substantive-manifest.json']:
 d=json.load(open(path));print(path, type(d),list(d)[:5]);v=d.get('artifacts',d.get('files'));print('first',str(v[0])[:300])
