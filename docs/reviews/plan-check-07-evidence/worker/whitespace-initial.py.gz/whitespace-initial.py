import subprocess,json,pathlib,re
root=pathlib.Path('/tmp/plan-check07-worker')
argv=['git','diff','--check','754a0b501fe705c93675ff09b43d5bfca201cd94','7fb302ba2829966c9a687a12a7f00d09ce6a7824']
r=subprocess.run(argv,capture_output=True);(root/'accepted-whitespace.stdout').write_bytes(r.stdout);(root/'accepted-whitespace.stderr').write_bytes(r.stderr)
paths=sorted(set(re.findall(r'^([^\n]+?):\d+:',r.stdout.decode(),re.M)))
assert r.returncode==2 and paths
assert all(p.startswith('docs/spikes/s06-evidence/') and (p.endswith('.log') or p=='docs/spikes/s06-evidence/raw-s06-todo.md') for p in paths),paths
argv2=argv+['--','.']+[':(exclude)'+p for p in paths]
r2=subprocess.run(argv2,capture_output=True);assert r2.returncode==0
(root/'accepted-authored-whitespace.stdout').write_bytes(r2.stdout);(root/'accepted-authored-whitespace.stderr').write_bytes(r2.stderr)
(root/'accepted-whitespace.json').write_text(json.dumps({'raw_command':argv,'raw_exit':r.returncode,'exact_raw_receipt_paths':paths,'authored_command':argv2,'authored_exit':r2.returncode,'no_bytes_changed':True},indent=2)+'\n')
print('historical whitespace',len(paths),'raw receipt paths; authored',r2.returncode)
