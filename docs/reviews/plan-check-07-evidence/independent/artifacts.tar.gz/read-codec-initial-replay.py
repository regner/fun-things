# Explicit replay of the original exploratory inline read; not an original execution receipt.
import subprocess,json,base64,gzip
n=json.loads(subprocess.check_output(['git','notes','--ref=paseo-orchestration','show','7fb302b']))
x=next(x for x in n['payloads'] if x['name']=='final-report'); t=gzip.decompress(base64.b64decode(x['data'])).decode(); print(t[:24000])
