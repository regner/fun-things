"""Sole-reviewer static ledger. Reads immutable Git and archives in memory only."""
import ast,base64,gzip,hashlib,io,json,os,re,stat,subprocess,tarfile
from pathlib import Path
from urllib.parse import unquote
D=Path('/tmp/plan-check07-independent-review'); R=Path.cwd()
BASE='7fb302ba2829966c9a687a12a7f00d09ce6a7824'; HEAD='b98cad76e2b33ef6f901285151e67616ad7b0aaf'; PRIOR='754a0b501fe705c93675ff09b43d5bfca201cd94'
def git(*a): return subprocess.check_output(['git',*a],cwd=R)
def sha(b): return hashlib.sha256(b).hexdigest()
def strict(b):
 def pairs(rows):
  d={}
  for k,v in rows:
   assert k not in d,('duplicate key',k)
   d[k]=v
  return d
 def bad(v): raise ValueError(v)
 return json.loads(b,object_pairs_hook=pairs,parse_constant=bad)
def verify(b,e):
 assert len(b)==e.get('bytes',e.get('size')),(e,len(b))
 assert sha(b)==e['sha256'],e
sources=[]
def source(rev,path):
 b=git('show',rev+':'+path); oid=git('rev-parse',rev+':'+path).decode().strip()
 sources.append({'revision':rev,'path':path,'git_blob':oid,'bytes':len(b),'sha256':sha(b)})
 return b
def tree(rev):
 out={}
 for line in git('ls-tree','-rz',rev).split(b'\0'):
  if line:
   meta,p=line.split(b'\t'); mode,kind,oid=meta.decode().split(); assert kind=='blob'; out[p.decode()]={'mode':mode,'oid':oid}
 return out
def pack(raw):
 out={}
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tf:
  for x in tf:
   assert x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts and x.name not in out,x.name
   out[x.name]=tf.extractfile(x).read()
 return out
sets=[]; notes=[]
def verify_set(label,actual,entries,extras):
 indexed={x['path']:x for x in entries}; assert len(indexed)==len(entries)
 assert set(actual)==set(indexed)|set(extras),(label,sorted(set(actual)^(set(indexed)|set(extras))))
 for p,e in indexed.items(): verify(actual[p],e)
 sets.append({'label':label,'count':len(actual),'indexed_count':len(entries),'actual_paths':sorted(actual),'expected_paths':sorted(set(indexed)|set(extras)),'hashes':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in actual.items()]})
def note(rev):
 oid=git('notes','--ref=paseo-orchestration','list',rev).decode().split()[0]; raw=git('cat-file','blob',oid); doc=strict(raw); out={}; ledger=[]
 for e in doc.get('payloads',doc.get('artifacts',[])):
  p=e.get('source_path',e.get('name')); assert p not in out
  stored=base64.b64decode(e['data'],validate=True)
  if 'stored_bytes' in e: assert len(stored)==e['stored_bytes'] and sha(stored)==e['stored_sha256']
  b=gzip.decompress(stored) if 'gzip' in e.get('codec','') else stored; verify(b,e); out[p]=b; ledger.append({k:v for k,v in e.items() if k!='data'})
 notes.append({'revision':rev,'notes_commit':git('rev-parse','refs/notes/paseo-orchestration').decode().strip(),'git_blob':oid,'bytes':len(raw),'sha256':sha(raw),'payloads':ledger,'actual_paths':sorted(out)})
 return doc,out
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','refs/heads/main').decode().strip()==BASE
assert git('branch','--show-current').decode().strip()=='plan-checkpoint-topology-capacity-readiness'
assert subprocess.run(['git','merge-base','--is-ancestor',PRIOR,BASE],capture_output=True).returncode==0
assert subprocess.run(['git','merge-base','--is-ancestor',BASE,HEAD],capture_output=True).returncode==0
seq=git('rev-list','--reverse',PRIOR+'..'+BASE).decode().split()
assert [x[:7] for x in seq]==['6b4a69e','096469f','1691424','dbce2f9','6c36c12','9cfa3c0','92f5471','bb7e902','1c49113','7fb302b']
commits=[]; prev=PRIOR
for rev in seq:
 assert git('show','-s','--format=%P',rev).decode().split()==[prev]
 old,new=tree(prev),tree(rev); changed={p:{'before':old.get(p),'after':new.get(p)} for p in sorted(set(old)|set(new)) if old.get(p)!=new.get(p)}
 diff=git('diff',prev,rev,'--','TODO.md','README.md','docs',':!docs/spikes/*-evidence',':!docs/reviews/*-evidence')
 (D/('delta-'+rev[:7]+'.diff')).write_bytes(diff)
 commits.append({'commit':rev,'parent':prev,'paths':changed,'planning_diff_bytes':len(diff),'planning_diff_sha256':sha(diff)});prev=rev
assert not git('rev-list','--merges',BASE+'..'+HEAD).strip()
base_tree,head_tree=tree(BASE),tree(HEAD); changes=sorted(p for p in set(base_tree)|set(head_tree) if base_tree.get(p)!=head_tree.get(p))
assert len(changes)==47
assert all(p in ['TODO.md','docs/reviews/plan-checkpoints.md','docs/reviews/plan-check-2026-10-08-07.md'] or p.startswith('docs/reviews/plan-check-07-evidence/') for p in changes)
protected=[]
for p,e in base_tree.items():
 if p in ['TODO.md','docs/reviews/plan-checkpoints.md']:continue
 assert head_tree[p]==e,p
 raw=(R/p).read_bytes(); assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==e['oid'],p
 mode='100755' if (R/p).stat().st_mode&stat.S_IXUSR else '100644'; assert mode==e['mode'],p
 protected.append({'path':p,**e})
assert len(protected)==2388
base_todo=source(BASE,'TODO.md').decode(); current=source(HEAD,'TODO.md').decode()
def tasks(t):
 matches=list(re.finditer(r'^- \[ \] \*\*([^ —]+) —',t,re.M)); out={}
 for m in matches:
  end=re.search(r'^(?:- \[ \]|##+ )',t[m.end():],re.M); stop=m.end()+end.start() if end else len(t); assert m[1] not in out; out[m[1]]=t[m.start():stop].rstrip()
 return out
old,new=tasks(base_todo),tasks(current); assert len(old)==27 and len(new)==29 and set(new)-set(old)=={'P0-DOC10','P0-DOC11'} and set(old)<=set(new)
revised=[k for k in old if old[k]!=new[k]];assert revised==['P0-PROFILES','S06','S07','P0-GATE']
record=source(HEAD,'docs/reviews/plan-check-2026-10-08-07.md').decode(); rows=re.findall(r'^\| ([A-Z][A-Z0-9-]*)(?: \(new\))? \|',record,re.M); assert len(rows)==29 and set(rows)==set(new)
json_paths=[]; links=[]
for p in changes:
 raw=source(HEAD,p)
 if p.endswith(('.md','.txt','.json','.py')):
  assert b'\r' not in raw and raw.endswith(b'\n'),p
  assert not any(x.endswith((b' ',b'\t')) for x in raw.splitlines()),p
 if p.endswith('.json'): strict(raw);json_paths.append(p)
 if p.endswith('.py'): ast.parse(raw)
 if not p.endswith('.md'):continue
 for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',raw.decode()):
  if re.match(r'\w+://',target):continue
  dest,sep,anchor=unquote(target).partition('#'); resolved=Path(os.path.normpath(str(Path(p).parent/dest))) if dest else Path(p)
  assert str(resolved) in head_tree,(p,target)
  if anchor:
   text=git('show',HEAD+':'+str(resolved)).decode(); heads=re.findall(r'^#+\s+(.+)$',text,re.M); slugs=[];counts={}
   for h in heads:
    s=re.sub(r'[^\w\- ]','',h.lower()).replace(' ','-');n=counts.get(s,0);counts[s]=n+1;slugs.append(s+('-'+str(n) if n else ''))
   assert anchor in slugs,(p,target)
  links.append({'path':p,'target':target})
assert len(links)==148
# Expected note sets independently use their complete manifest, never a broad filename filter.
d6,p6=note('096469f'); prefix='/tmp/plan-check06-independent-final-review/'
m6=strict(p6[prefix+'manifest.json']); a6=pack(p6[prefix+'final-review-artifacts.tar.gz']); verify_set('sixth exact-final archive',a6,m6['files'],['manifest.json'])
d89,p89=note('6c36c12');assert len(p89)==177
for directory,count in [('doc89-independent-review',66),('doc89-independent-final-review',27),('doc89-independent-renewed-review',16)]:
 pre='/tmp/'+directory+'/';entries=strict(p89[pre+'manifest.json'])['entries'];assert len(entries)==count
 verify_set(directory,{k[len(pre):]:v for k,v in p89.items() if k.startswith(pre)},entries,['manifest.json','SHA256SUMS'])
ds,ps=note(BASE);assert len(ps)==15
named={e['name']:ps[e['source_path']] for e in ds['payloads']}
fm=strict(named['final-manifest']); af=pack(named['all-185-final-review-artifacts']);verify_set('S06 exact-final archive',af,fm['local_artifacts'],['manifest.json','handoff-hashes.json']);assert len(af)==185
sm=strict(source(BASE,'docs/spikes/s06-evidence/review/substantive-manifest.json')); orig=pack(source(BASE,'docs/spikes/s06-evidence/review/substantive-artifacts.tar.gz'));verify_set('S06 original substantive archive',orig,sm['local_artifacts'],['manifest.json','handoff-hashes.json']);assert len(orig)==218
manifest=strict(source(BASE,'docs/spikes/s06-evidence/manifest.json'));entries=manifest['artifacts'];assert len(entries)==509
for e in entries:verify(git('show',BASE+':docs/spikes/s06-evidence/'+e['artifact']),e)
old_manifest=strict(source('bb7e902','docs/spikes/s06-evidence/manifest.json'));assert len(old_manifest['artifacts'])==359
for e in old_manifest['artifacts']:
 matches=[x for x in entries if x.get('original_artifact',x['artifact'])==e['artifact']];assert any(all(x[k]==e[k] for k in ['bytes','sha256','input']) for x in matches),e
sets.append({'label':'S06 committed current and original manifests','current_count':509,'original_count':359,'current_entries':entries,'original_entries':old_manifest['artifacts']})
refrows=ds['committed_experiment_artifact_references']+ds['source_and_task_references'];assert len(refrows)==552 and len({x['path'] for x in refrows})==552
for e in refrows:assert git('rev-parse',BASE+':'+e['path']).decode().strip()==e['git_blob'];verify(git('cat-file','blob',e['git_blob']),e)
prior=ds['verified_prior_note_reference'];rawprior=git('cat-file','blob',prior['git_blob']);verify(rawprior,prior);hist=strict(rawprior);assert ds['payloads'][:11]==hist['payloads'] and len(hist['payloads'])==11
assert subprocess.run(['git','merge-base','--is-ancestor',prior['notes_commit'],'refs/notes/paseo-orchestration'],capture_output=True).returncode==0
assert prior['git_blob'] in git('ls-tree','-r',prior['notes_commit']).decode()
ack=strict(named['complete-acknowledgement-manifest']);supp=pack(named['all-supplementary-acknowledgement-raw-artifacts']);ret=strict(named['supplementary-retention-and-exact-note-blob-references']);history={x['path']:x for x in ret['two_identical_historical_note_readbacks_retained_by_exact_blob_references']};assert len(history)==2
ackfull={e['path']:rawprior if e['path'] in history else supp[e['path']] for e in ack['artifacts']}; assert len(ackfull)==11
verify_set('S06 acknowledgement complete inputs',ackfull,ack['artifacts'],[])
assert set(supp)==(set(ackfull)-set(history))|{'note-acknowledgement-manifest.json','note-acknowledgement-retention.json'}
# Worker compression is transport, not permission to omit failures.
wr=strict(source(HEAD,'docs/reviews/plan-check-07-evidence/worker-retention.json'))
assert set(wr['expected_source_paths'])=={e['source_path'] for e in wr['entries']} and len(wr['entries'])==len(wr['expected_source_paths'])
assert {e['artifact'] for e in wr['entries']}=={p for p in changes if p.startswith('docs/reviews/plan-check-07-evidence/worker/')}
for e in wr['entries']:
 stored=git('show',HEAD+':'+e['artifact']); assert len(stored)==e['stored_bytes'] and sha(stored)==e['stored_sha256']; verify(gzip.decompress(stored),e)
sets.append({'label':'checkpoint07 worker original raw outputs','expected_source_paths':wr['expected_source_paths'],'entries':wr['entries']})
# Current root receipt comes from accepted note, with immutable hash and time-specific assertions.
rr=next(x for x in ds['root_receipts'] if 'complete_receipt' in x); receipt=rr['complete_receipt'];assert len(receipt['artifact_ledger'])==150
receipt_raw=Path('/tmp/s06-editor-relocation/receipt.json').read_bytes();verify(receipt_raw,{'bytes':23635,'sha256':'ad8b5589fe3d0dab5c7e75d9cb8ebb953b299ba06f6d9296319417c7f676bfa9'});assert strict(receipt_raw)==receipt
for p,e in receipt['artifact_ledger'].items():verify((Path('/tmp/s06-editor-relocation')/p).read_bytes(),e)
# Complete required inputs and relevant contracts get immutable identity, not copied source trees.
inputs=['AGENTS.md','.agents/skills/paseo-orchestrator/SKILL.md','README.md','docs/development.md','docs/assets.md','docs/multiplayer.md','docs/architecture.md','docs/scene-structure.md','docs/api-contracts.md','docs/world-layout.md','docs/design.md','docs/art-direction.md','docs/asset-catalogue.md','docs/assets/s02_kit.md','docs/assets/s04_kit.md','docs/spikes/s06.md','docs/spikes/s06-contracts.md','docs/spikes/s06-source-handoff.md','docs/spikes/s07.md','docs/spikes/s06-evidence/README.md','docs/spikes/s06-evidence/review/substantive-report.md','docs/reviews/plan-check-2026-10-08-06.md','docs/reviews/plan-check-review-2026-10-08-06.md','docs/reviews/p0-doc8.md','docs/reviews/p0-doc9.md','docs/workflows/p0-profiles-proposal.md','docs/workflows/p0-profiles-evidence.md','docs/workflows/p0-profiles-evidence/proposed.patch.json','docs/workflows/p0-profiles-evidence/schema-source.json','docs/workflows/p0-profiles-evidence/sample-coverage.json','tools/s06/run.py','tools/s06/check_resources.py','tools/s06/editor_probe.gd','tests/fixtures/s06/intersection.tscn','tests/fixtures/s06/intersection_wide.tscn','tests/fixtures/s06/west.tscn','tests/fixtures/s06/east.tscn']
for p in inputs:source(BASE,p)
metadata=strict((D/'metadata.json').read_bytes());own=metadata['own_status']['value']['structuredContent']['snapshot'];assert own['id']=='7b26565d-a48e-4f1a-a6b0-d2c04f5ba7cc' and own['model']=='gpt-6.1-sol' and own['thinkingOptionId']==own['effectiveThinkingOptionId']=='high' and own['currentModeId']=='auto-review';assert own['runtimeInfo']['extra']['collaborationMode']=='Default';assert metadata['profiles']['value']['structuredContent']['profiles']==[]
status=git('status','--porcelain=v1','--untracked-files=all').decode();assert status==''
for p in ['MERGE_HEAD','CHERRY_PICK_HEAD','REVERT_HEAD','rebase-merge','rebase-apply','sequencer','BISECT_LOG','index.lock']:assert not Path(git('rev-parse','--git-path',p).decode().strip()).exists(),p
out={'exact_head':HEAD,'base':BASE,'prior_exclusive':PRIOR,'commits':commits,'candidate_paths':changes,'protected_mode_blob_paths':protected,'base_task_ids':list(old),'current_task_ids':list(new),'revised':revised,'links':links,'json_paths':json_paths,'notes':notes,'expected_sets':sets,'s06_552_git_refs':refrows,'root_receipt_identity':{'bytes':len(receipt_raw),'sha256':sha(receipt_raw),'ledger_count':150},'sources':sources,'status':status,'own_metadata_verified':True,'static_only':True}
(D/'independent-result.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS exact refs, ten parents/deltas, 47-path scope, 2388 preserved entries, 27->29 tasks, four revised,148 links, strict JSON/LF/AST, complete expected archive/note/manifest sets, root receipt ledger, own HIGH, clean Git.')
