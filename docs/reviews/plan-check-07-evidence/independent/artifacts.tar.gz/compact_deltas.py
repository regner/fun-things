import json,subprocess,hashlib
from pathlib import Path
D=Path('/tmp/plan-check07-independent-review')
ledger=[]
seq=subprocess.check_output(['git','rev-list','--reverse','754a0b5..7fb302b']).decode().split();prev='754a0b501fe705c93675ff09b43d5bfca201cd94'
for rev in seq:
 p=D/('delta-'+rev[:7]+'.diff');old=p.read_bytes()
 args=['git','diff',prev,rev,'--','TODO.md','README.md','docs',':(glob,exclude)docs/spikes/*-evidence/**',':(glob,exclude)docs/reviews/*-evidence/**']
 new=subprocess.check_output(args);p.write_bytes(new)
 ledger.append({'revision':rev,'parent':prev,'discarded_redundant_historical_diff_bytes':len(old),'discarded_redundant_historical_diff_sha256':hashlib.sha256(old).hexdigest(),'old_reproducible_git_argv':['git','diff',prev,rev,'--','TODO.md','README.md','docs',':!docs/spikes/*-evidence',':!docs/reviews/*-evidence'],'retained_compact_git_argv':args,'retained_bytes':len(new),'retained_sha256':hashlib.sha256(new).hexdigest()});prev=rev
(D/'delta-transport-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');print('Retained compact documentation deltas:',sum(x['retained_bytes'] for x in ledger),'bytes; old evidence remains immutable Git refs, no multiMB historical raw dump retained.')
