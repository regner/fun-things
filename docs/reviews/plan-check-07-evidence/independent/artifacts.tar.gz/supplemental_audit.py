import base64,gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
D=Path('/tmp/plan-check07-independent-review');BASE='7fb302ba2829966c9a687a12a7f00d09ce6a7824'
def git(*a):return subprocess.check_output(['git',*a])
def sha(b):return hashlib.sha256(b).hexdigest()
def strict(b):
 def pairs(rows):
  d={}
  for k,v in rows:assert k not in d,k;d[k]=v
  return d
 def bad(v):raise ValueError(v)
 return json.loads(b,object_pairs_hook=pairs,parse_constant=bad)
def verify(b,e):assert len(b)==e['bytes'] and sha(b)==e['sha256'],e
r=strict(git('show',BASE+':docs/reviews/plan-check-06-evidence/independent-retention.json')); decoded={}
for e in r['artifacts']:
 stored=git('show',BASE+':docs/reviews/plan-check-06-evidence/'+e['retained']);assert len(stored)==e['stored_bytes'] and sha(stored)==e['stored_sha256'];raw=gzip.decompress(stored) if e['gzip'] else stored;verify(raw,e);decoded[e['source_path']]=raw
pre='/tmp/plan-check06-independent-review/'; mf=strict(decoded[pre+'manifest.json']);dl=strict(decoded[pre+'delivery-ledger.json']);assert len(mf['files'])==215 and len(dl['files'])==221
with tarfile.open(fileobj=io.BytesIO(decoded[pre+'review-artifacts.tar.gz']),mode='r:gz') as tf:
 members={}
 for x in tf:
  assert x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts and x.name not in members,x.name
  members[x.name]=tf.extractfile(x).read()
assert set(members)=={e['path'] for e in mf['files']}|{'manifest.json'}
assert members['manifest.json']==decoded[pre+'manifest.json']
for e in mf['files']:verify(members[e['path']],e)
for e in dl['files']:verify(members[e['path']] if e['path'] in members else decoded[pre+e['path']],e)
# Compare worker's accepted audit to a fresh executed output; stored wrapper identity can be historical.
a=strict(git('show',BASE.replace(BASE,'b98cad76e2b33ef6f901285151e67616ad7b0aaf')+':docs/reviews/plan-check-07-evidence/accepted-audit.json'));b=strict((D/'candidate-accepted-result.json').read_bytes())
assert a==b
out={'sixth_original_pack_entries':215,'sixth_original_archive_paths':sorted(members),'sixth_original_manifest':mf,'sixth_complete_delivery_ledger':dl,'sixth_retained_delivery_paths':sorted(decoded),'candidate_accepted_audit_full_equality':True,'strict_json':True}
(D/'supplemental-result.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS sixth original215/full221 exact paths and hashes; complete candidate accepted-audit equals fresh static readback.')
