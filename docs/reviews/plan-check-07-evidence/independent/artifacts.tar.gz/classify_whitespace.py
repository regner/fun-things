import json,re,subprocess,hashlib
from pathlib import Path
D=Path('/tmp/plan-check07-independent-review');s=(D/'accepted-whitespace.stdout').read_text();paths=sorted(set(re.findall(r'^([^\n]+?):\d+: ',s,re.M)))
assert len(paths)==358
assert all(p.startswith('docs/spikes/s06-evidence/') and (p.endswith('.log') or p in ['docs/spikes/s06-evidence/raw-s06-todo.md','docs/spikes/s06-evidence/accepted-docs-delta.patch']) for p in paths)
argv=['git','diff','--check','754a0b5','7fb302b','--','.']+[':(exclude)'+p for p in paths]
p=subprocess.run(argv,capture_output=True);(D/'accepted-authored-whitespace.stdout').write_bytes(p.stdout);(D/'accepted-authored-whitespace.stderr').write_bytes(p.stderr)
(D/'accepted-whitespace-classification.json').write_text(json.dumps({'exact_historical_raw_paths':paths,'argv':argv,'exit':p.returncode,'raw_output_sha256':hashlib.sha256(s.encode()).hexdigest(),'no_payload_removed':True},indent=2)+'\n');assert p.returncode==0;print('358 exact historical raw paths classified; accepted authored whitespace PASS, payloads unchanged and complete.')
