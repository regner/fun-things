from pathlib import Path
import ast, hashlib, json, sys

ROOT = Path('/tmp/plan-check07-independent-review')
EXCLUDED = {'manifest.json', 'SHA256SUMS'}
CANDIDATE = 'b98cad76e2b33ef6f901285151e67616ad7b0aaf'
BASE = '7fb302ba2829966c9a687a12a7f00d09ce6a7824'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def unique(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('duplicate JSON key: ' + key)
        out[key] = value
    return out

def files():
    result = {}
    for path in sorted(ROOT.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file() and path.relative_to(ROOT).as_posix() not in EXCLUDED:
            relative = path.relative_to(ROOT).as_posix()
            data = path.read_bytes()
            result[relative] = {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}
    return result

def audit():
    entries = files()
    json_paths, python_paths = [], []
    for name in entries:
        data = (ROOT / name).read_bytes()
        if name.endswith('.json'):
            json.loads(data, object_pairs_hook=unique)
            json_paths.append(name)
        if name.endswith('.py'):
            ast.parse(data, filename=name)
            python_paths.append(name)
    report = (ROOT / 'report.md').read_bytes()
    assert b'\r' not in report and report.endswith(b'\n')
    assert (ROOT / 'final-git-status.stdout').read_bytes() == b''
    assert (ROOT / 'final-refs.stdout').read_text().splitlines() == [CANDIDATE, BASE]
    for stem in ['candidate-check', 'independent-audit-final', 'supplemental-audit',
                 'authored-whitespace', 'final-git-status', 'final-refs']:
        receipt = json.loads((ROOT / (stem + '.command.json')).read_bytes(), object_pairs_hook=unique)
        assert receipt['exit'] == 0, (stem, receipt)
    return {'candidate': CANDIDATE, 'base': BASE, 'report': entries['report.md'],
            'strict_json_paths': json_paths, 'ast_only_python_paths': python_paths,
            'own_saved_quiescent': True, 'all_own_static_children_complete': True,
            'candidate_unchanged_clean': True, 'verdict': 'ACCEPT exact candidate only',
            'future_lead_note_storage_verified': False}

if sys.argv[1:] == ['--audit']:
    result = audit()
    (ROOT / 'finalization-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True))
elif sys.argv[1:] == ['--seal']:
    audit()
    entries = files()
    ledger = ''.join(f"{entry['sha256']}  {name}\n" for name, entry in entries.items()).encode()
    (ROOT / 'SHA256SUMS').write_bytes(ledger)
    expected = sorted(entries)
    actual = sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file())
    assert actual == sorted(expected + ['SHA256SUMS']) or actual == sorted(expected + list(EXCLUDED))
    manifest = {'schema': 'independent-static-review-artifact-manifest-v1',
                'root': str(ROOT), 'candidate': CANDIDATE, 'base': BASE,
                'reviewer_id': '7b26565d-a48e-4f1a-a6b0-d2c04f5ba7cc',
                'report': entries['report.md'], 'payload_count': len(entries),
                'payload_total_bytes': sum(e['bytes'] for e in entries.values()),
                'expected_payload_path_set': expected, 'actual_payload_path_set': expected,
                'expected_complete_path_set': sorted(expected + list(EXCLUDED)),
                'actual_complete_path_set': sorted(expected + list(EXCLUDED)),
                'self_index_exclusions': sorted(EXCLUDED),
                'checksum_ledger': {'bytes': len(ledger), 'sha256': digest(ledger)},
                'artifacts': entries}
    (ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    decoded = json.loads((ROOT / 'manifest.json').read_bytes(), object_pairs_hook=unique)
    assert decoded == manifest
    actual = sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file())
    assert actual == manifest['expected_complete_path_set']
    for name, entry in decoded['artifacts'].items():
        raw = (ROOT / name).read_bytes()
        assert len(raw) == entry['bytes'] and digest(raw) == entry['sha256'], name
    assert (ROOT / 'SHA256SUMS').read_bytes() == ledger
    raw_manifest = (ROOT / 'manifest.json').read_bytes()
    print(json.dumps({'manifest_path': str(ROOT / 'manifest.json'),
                      'manifest_bytes': len(raw_manifest), 'manifest_sha256': digest(raw_manifest),
                      'report': entries['report.md'], 'payload_count': len(entries),
                      'complete_artifact_count': len(actual),
                      'payload_total_bytes': manifest['payload_total_bytes'],
                      'actual_path_set_and_all_hash_readbacks_verified': True}, indent=2))
else:
    raise ValueError('expected --audit or --seal')
