import subprocess,json,hashlib,sys
from pathlib import Path
D=Path('/tmp/plan-check07-independent-review'); R=Path.cwd()
def run(name,args):
 p=subprocess.run(args,cwd=R,capture_output=True)
 for suffix,data in [('stdout',p.stdout),('stderr',p.stderr)]: (D/(name+'.'+suffix)).write_bytes(data)
 meta={'argv':args,'cwd':str(R),'exit':p.returncode,'stdout_bytes':len(p.stdout),'stderr_bytes':len(p.stderr),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
 (D/(name+'.command.json')).write_text(json.dumps(meta,indent=2)+'\n'); print(json.dumps(meta)); return p
if __name__=='__main__': run(sys.argv[1],sys.argv[2:])
