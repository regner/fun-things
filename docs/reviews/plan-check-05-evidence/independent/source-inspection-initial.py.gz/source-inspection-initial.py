import json,pathlib
for n in ['fix-enet/result.json','negative-producer/result.json','fix-api/result.json']:
 d=json.loads((pathlib.Path('docs/spikes/s04-evidence')/n).read_text())
 if n=='fix-enet/result.json':
  for p in d['profiles']: print(p['profile'],{k:v for k,v in p['measurements'].items() if k!='responses'})
 elif n=='fix-api/result.json': print(n,[(p.keys()) for p in d['results']])
 else: print(n,d)
