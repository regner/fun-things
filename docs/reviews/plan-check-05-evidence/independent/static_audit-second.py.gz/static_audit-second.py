"""Independent frozen checkpoint integrity; local bytes/Git only, no project imports."""
from pathlib import Path
import ast,base64,gzip,hashlib,io,json,re,subprocess,tarfile,unicodedata
from urllib.parse import urlsplit,unquote
ROOT=Path.cwd(); OUT=Path('/tmp/plan-check05-independent-review')
HEAD='a509ca99d9bfb675b0b31464cd2a03bd001155c1'
BASE='ca38e4fc55b32a379ef7e3bf947e27d4ca8edc4c'
PRIOR='8d60ff68bf2091f3077371de00b9b06960cec5ae'
INITIAL='2370ad1c182b46e51f5dc4c6b6ab6157819e84b0'
RECORD='docs/reviews/plan-check-2026-10-08-05.md'
EXPECTED=['0f87146','8b6dc30','0ce40d9','14a150b','04f16d3','10874476','d4cce25','2370ad1','673ae56','826e431','ca38e4f']
IDS=['P0-PROFILES','P0-DOC6','P0-DOC7','S02','S03-S','S03-R','S04','S05','S06','S07','S08','P0-GATE','M1-A1','M1-A2','M1-A3','M1-A-GATE','M1-B1','M1-B2','M1-B3','M1-B4','M1-C1','M1-C2','M1-C3','M1-C4','M1-D1','M1-D2','M1-D3','M1-D4','M1-GATE']
ALLOWED={'TODO.md',RECORD,'docs/reviews/plan-checkpoints.md',*[f'docs/reviews/plan-check-05-evidence/{x}' for x in ['check.py','audit-manifest.json','profile-discovery.json','requirements.txt','root-updates.txt']],*[f'docs/reviews/plan-check-05-evidence/accepted-notes/{x}.txt.gz' for x in ['8b6dc30','04f16d3','2370ad1','ca38e4f']]}

def git(*a):
 return subprocess.check_output(['git',*a],timeout=30)

def pairs(p):
 d={}
 for k,v in p:
  assert k not in d,k
  d[k]=v
 return d

def js(p): return json.loads(Path(p).read_text(),object_pairs_hook=pairs)
def h(b): return hashlib.sha256(b).hexdigest()
def same(b,e): assert len(b)==e['bytes'] and h(b)==e['sha256'],e

def blocks(t):
 lines=t.splitlines(keepends=True); result={}; key=None
 for line in lines:
  m=re.match(r'^- \[ \] \*\*([A-Z0-9-]+) —',line)
  if m:
   key=m[1]; assert key not in result;result[key]=[]
  elif re.match(r'^#{1,3} ',line): key=None
  if key:result[key].append(line)
 return {k:''.join(v).rstrip() for k,v in result.items()}

def tree(rev):
 return dict((line.split(b'\t',1)[1].decode(),line.split(b'\t',1)[0]) for line in git('ls-tree','-r',rev).splitlines())

def anchors(p):
 counts={}; result=set()
 s=re.sub(r'(?ms)^```.*?^```[^\n]*\n?', '', p.read_text())
 for line in s.splitlines():
  m=re.match(r'^#{1,6}\s+(.+?)\s*#*$',line)
  if not m:continue
  title=re.sub(r'[`*_]','',m[1]).lower()
  slug=''.join(c for c in title if c in ' -_' or unicodedata.category(c)[0] in 'LN').replace(' ','-')
  n=counts.get(slug,0);counts[slug]=n+1;result.add(slug+(f'-{n}' if n else ''))
 return result

assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','refs/heads/main').decode().strip()==BASE
assert not git('status','--porcelain=v1','-uall').strip()
revs=git('rev-list','--reverse',PRIOR+'..'+BASE).decode().splitlines()
assert len(revs)==len(EXPECTED) and all(r.startswith(e) for r,e in zip(revs,EXPECTED))
for prev,rev in zip([PRIOR]+revs,revs):assert git('show','-s','--format=%P',rev).decode().strip()==prev
assert len(git('rev-list',PRIOR+'..'+INITIAL).splitlines())==8
assert len(git('rev-list',INITIAL+'..'+BASE).splitlines())==3
assert not git('rev-list','--merges',PRIOR+'..'+HEAD).strip()
subprocess.run(['git','merge-base','--is-ancestor',BASE,HEAD],check=True)
changed=set(git('diff','--name-only',BASE,HEAD).decode().splitlines());assert changed==ALLOWED,(changed^ALLOWED)
old,new=tree(BASE),tree(HEAD)
kept=0
for p,v in old.items():
 if p not in {'TODO.md','docs/reviews/plan-checkpoints.md'}:
  assert new[p]==v,p
  assert (ROOT/p).read_bytes()==git('show',BASE+':'+p),p
  kept+=1
print('PASS frozen exact HEAD/base, eleven sole-parent accepted commits initial8/new3, ancestry/zero merges, exact12-path scope;',kept,'other mode/blob/working entries preserved')
before=blocks(git('show',BASE+':TODO.md').decode()); after=blocks(Path('TODO.md').read_text())
assert list(after)==IDS and list(before)==[i for i in IDS if i not in {'P0-DOC6','P0-DOC7'}]
assert len(before)==27 and len(after)==29
assert re.findall(r'^\| ([A-Z0-9-]+) \|',Path(RECORD).read_text(),re.M)==IDS
revised={'P0-PROFILES','S04','S05','S06','P0-GATE'}
assert {k for k in before if before[k]!=after[k]}==revised
for k in ['S02','S03-S','S03-R','S07','S08']+[k for k in IDS if k.startswith('M1')]:assert before[k]==after[k],k
assert 'P0-DOC6/P0-DOC7' in after['P0-GATE']
assert Path('TODO.md').read_text().split('## First milestone — implementation',1)[1].split('## Parallel work',1)[0]==git('show',BASE+':TODO.md').decode().split('## First milestone — implementation',1)[1].split('## Parallel work',1)[0]
assert BASE in Path('docs/reviews/plan-checkpoints.md').read_text()
assert Path(RECORD).name in Path('docs/reviews/plan-checkpoints.md').read_text()
assert '8d60ff68bf2091f3077371de00b9b06960cec5ae' in Path(RECORD).read_text()
print('PASS explicit27/29 task IDs/order, once-only complete dispositions, five revised existing blocks, unchanged full M1 and partial-gate tasks; DOC6/DOC7 only additions, no removal/reopening')
m=js('docs/reviews/plan-check-05-evidence/audit-manifest.json')
assert m['base']==m['inclusive_watermark']==BASE and m['prior_exclusive']==PRIOR
assert [e['revision'] for e in m['commits']]==revs
for e in m['commits']:
 assert e['parents']==git('show','-s','--format=%P',e['revision']).decode().split()
 assert e['paths']==git('diff-tree','--no-commit-id','--name-only','-r',e['revision']).decode().splitlines()
for e in m['consulted_records']:same(git('show',e['revision']+':'+e['path']),e)
notes={}
for e in m['notes']:
 raw=gzip.decompress((ROOT/'docs/reviews/plan-check-05-evidence'/e['snapshot']).read_bytes());same(raw,e)
 assert git('notes','--ref=paseo-orchestration','show',e['revision']).startswith(raw)
 notes[e['revision'][:7]]=raw
s04=notes['2370ad1']
packed=re.search(rb'--- BEGIN BASE64 EXACT-FINAL ARTIFACT TAR.GZ ---\s*(.*?)\s*--- END BASE64 EXACT-FINAL ARTIFACT TAR.GZ ---',s04,re.S)
blob=base64.b64decode(packed[1]); assert h(blob)=='739b2cdefcec27c682b1e57f5e7d5179b4e7f15c3a915f3d57b5cd1fda3ecd2a'
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as arc:
 payloads={item.name:arc.extractfile(item).read() for item in arc if item.isfile()}
ret=json.loads(payloads['final-retention-manifest.json']); assert len(ret['files'])==28
for e in ret['files']:
 if e['path'] in payloads: raw=payloads[e['path']]
 else:raw=gzip.decompress((ROOT/(e['path'].replace('final-followup/raw-','docs/spikes/s04-evidence/fix-enet/')+'.gz')).read_bytes())
 same(raw,e)
assert payloads['review-2370ad1-final.md'] in s04
receipt=s04.split(b'# S04 editor relocation receipt',1)[1]
receipt=b'# S04 editor relocation receipt'+receipt
same(receipt[:m['relocation_receipt']['bytes']],m['relocation_receipt'])
compat=notes['ca38e4f']
ledger=json.JSONDecoder(object_pairs_hook=pairs).raw_decode(compat.split(b'Full artifact integrity ledger:\n',1)[1].decode())[0]
assert len(ledger)==17
for e in ledger:
 kind='WORKER RECEIPT' if e['path'].startswith('worker/') else 'REBASE RECEIPT'
 name=e['path'].removeprefix('worker/')
 raw=compat.split(('--- BEGIN '+kind+' '+name+' ---\n').encode(),1)[1].split(('\n--- END '+kind+' '+name+' ---').encode(),1)[0]
 same(raw[:e['bytes']],e);assert raw[e['bytes']:] in (b'',b'\n',b'\n\n'),e['path']
ret=js('docs/reviews/s03-s-compatibility-evidence/retention.json')['artifacts']; assert len(ret)==23
for e in ret:same((ROOT/e['retained']).read_bytes(),e)
print('PASS manifest eleven commits/parents/paths and55 consulted hashes; four full note snapshots; S04 packed28 exact payloads, byte-faithful final report and relocation receipt; S03-S seventeen note/twenty-three original receipts')
links=[]; jcount=0
for p in sorted(ALLOWED):
 raw=(ROOT/p).read_bytes()
 if p.endswith('.gz'):gzip.decompress(raw);continue
 assert b'\r' not in raw and raw.endswith(b'\n'),p
 assert all(l.rstrip(b' \t')==l for l in raw.splitlines()),p
 if p.endswith('.json'):js(p);jcount+=1
 if p.endswith('.py'):ast.parse(raw)
 if not p.endswith('.md'):continue
 content=re.sub(r'(?ms)^```.*?^```[^\n]*\n?', '',raw.decode())
 for target in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',content):
  url=urlsplit(target.strip('<>'))
  if url.scheme:continue
  dest=(ROOT/p).parent/unquote(url.path) if url.path else ROOT/p
  dest=dest.resolve();assert dest.exists(),(p,target)
  if url.fragment and dest.suffix=='.md':assert unquote(url.fragment) in anchors(dest),(p,target)
  links.append([p,target,str(dest)])
(OUT/'links.json').write_text(json.dumps(links,indent=2)+'\n')
subprocess.run(['git','diff','--check',BASE,HEAD],check=True)
print('PASS',len(links),'local links/anchors;',jcount,'duplicate-key JSONs; Python AST; authored LF/newline/trailing whitespace; no authored frontmatter changed')
d=js('docs/reviews/plan-check-05-evidence/profile-discovery.json');assert d['profiles']['structuredContent']['profiles']==[]
proposed=js('docs/workflows/p0-profiles-evidence/proposed.patch.json')['agentProfiles']
assert len(proposed)==len({p['id'] for p in proposed})==4
assert [(p['model'],p['thinkingOptionId']) for p in proposed]==[('gpt-6.1-sol','medium'),('gpt-6.1-sol','high'),('gpt-6-luna','high'),('gpt-6-astra','high')]
models={m['id']:m for m in d['models']['structuredContent']['models']}
for p in proposed:
 assert p['thinkingOptionId'] in {e['id'] for e in models[p['model']]['thinkingOptions']}
 assert p['modeId']=='auto-review' and p['featureValues']['plan_mode'] is False
 assert p['notes'] and 'grants no MCP' in p['notes']
sol=d['corrected_sol_inspection']['structuredContent'];assert sol['selectedModel']=='gpt-6.1-sol'
assert any(m['id']=='auto-review' for m in sol['modes'])
assert [f['id'] for f in sol['features']]==['plan_mode'] and sol['features'][0]['value'] is False
sessions=[e['structuredContent'] for e in d['bounded_session_metadata']]
assert [e['snapshot']['id'] for e in sessions]==['23383c25-3246-4ab9-bc26-64b35cbae1db','28209f2c-6472-4c75-979a-ca5d9c5c5fe6','4b965847-a374-47da-aa0e-2800adaebc4f']
assert [e['snapshot']['effectiveThinkingOptionId'] for e in sessions]==['medium','medium','high']
print('PASS captured zero installed/four inert proposal declarations, supported exact Sol/Luna/Astra efforts/mode/features, targeted DOC5/S04 session settings; metadata is no installed launch/permission proof')
canon=js('docs/spikes/s04-evidence/canonical/result.json');fix=js('docs/spikes/s04-evidence/fix-enet/result.json')
for data,expect in [(canon,[97,269,401]),(fix,[248,380])]:
 assert data['ok']
 assert [p['measurements']['response_p95_ms']['physics_ms'] for p in data['profiles']]==expect
 for p in data['profiles']:
  measures=p['measurements'];assert measures['response_samples']==20 and measures['physics_response_missing']==0
  assert measures['response_p95_ms']['rendered_frame_ms'] is None
  assert all(r['rendered_frame_ms'] is None for r in measures['responses'])
assert js('docs/spikes/s04-evidence/fix-api/result.json')['results']==dict(body=True,baseline=True,fence=True,producer=True)
neg=js('docs/spikes/s04-evidence/negative-producer/result.json');assert neg['expected_exit']==neg['actual_exit']==1 and neg['runtime_diagnostics'] is False
raw=gzip.decompress(Path('docs/spikes/s04-evidence/negative-producer/probe.log.gz').read_bytes()).decode()
events=[json.loads(line.split(' ',1)[1]) for line in raw.splitlines() if line.startswith('S04_PRODUCER ')]
if not events:
 events=[json.loads(line[line.index('{'):]) for line in raw.splitlines() if '{' in line and 'failures' in line]
assert any(len(e.get('failures',[]))==14 for e in events),raw
assert abs(fix['profiles'][1]['measurements']['recovery'][0]['observed_delay_ms']-163.215087890625)<0.000001
assert abs(fix['profiles'][1]['measurements']['recovery'][1]['observed_delay_ms']-150.119873046875)<0.000001
print('PASS retained S0497/269/401 historical versus248/380 correction20/20 physics/null drawn, four API pass booleans and actual fourteen-failure/no-diagnostic negative; adverse recovery163.215/150.120; no metric rerun')
ops=['rebase-merge','rebase-apply','MERGE_HEAD','CHERRY_PICK_HEAD','REVERT_HEAD','BISECT_LOG','index.lock','sequencer']
assert not any(Path(git('rev-parse','--git-path',op).decode().strip()).exists() for op in ops)
assert not git('status','--porcelain=v1','-uall').strip()
assert git('rev-parse','HEAD','refs/heads/main').decode().splitlines()==[HEAD,BASE]
print('PASS final exact HEAD/base, clean tracked/untracked and no active Git operation/index lock; owned static children completed, reviewer saved/quiescent; no shared surface query/lease or experiment')
