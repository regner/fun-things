from pathlib import Path
import hashlib,json,os,re,subprocess,time
D=Path('/tmp/smg-independent-xir6orth')
P=D/'project'
records=json.loads(Path('/home/regner/.paseo/worktrees/0u71f39f/brackett-smg/docs/assets/smg_wedgewire_a_evidence/clean_import.json').read_text())['inputs']
def snapshot():
    rows=[]
    for original in records:
        path=P/original['path']; data=path.read_bytes()
        uid=re.findall(r'uid="(uid://[^\"]+)"',data.decode()) if path.suffix in ['.tscn','.import'] else ([data.decode().strip()] if path.suffix=='.uid' else [])
        rows.append({'path':original['path'],'sha256':hashlib.sha256(data).hexdigest(),'uids':uid})
    return rows
before=snapshot()
assert all(row['sha256']==original['sha256'] for row,original in zip(before,records)), 'Scratch input drift before import'
cache=P/'.godot'
assert not (D/'initial-import-cache').exists()
if cache.exists(): cache.rename(D/'initial-import-cache')
# Private process state; no addons, autoloads, registry or shared configuration.
env=os.environ.copy()
for key,part in [('XDG_DATA_HOME','data'),('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_RUNTIME_DIR','runtime')]:
    directory=D/('listener-followup-'+part); directory.mkdir(mode=0o700,exist_ok=True); env[key]=str(directory)
argv=['/home/regner/.local/share/mise/installs/github-godotengine-godot-builds/4.8-dev7/godot','--path',str(P),'--headless','--editor','--debug-server','tcp://127.0.0.1:21607','--import','--quit']
started=time.monotonic()
try:
    run=subprocess.run(argv,env=env,capture_output=True,text=True,timeout=45)
    output=run.stdout+run.stderr; code=run.returncode
except subprocess.TimeoutExpired as error:
    output=(error.stdout or b'').decode(errors='replace')+(error.stderr or b'').decode(errors='replace'); code='timeout45'
(D/'listener-followup-import.log').write_text(output)
after=snapshot()
result={'argv':argv,'exit':code,'elapsed_seconds':time.monotonic()-started,'fresh_import_cache':True,'private_debug_port':21607,'diagnostics':[line for line in output.splitlines() if re.search(r'ERROR:|WARNING:|SCRIPT ERROR:',line)],'before':before,'after':after,'input_bytes_and_uids_preserved':before==after,'generated_imports':[str(f.relative_to(P)) for f in (P/'.godot/imported').glob('*.scn')]}
(D/'listener-followup-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ['before','after']},indent=2))
