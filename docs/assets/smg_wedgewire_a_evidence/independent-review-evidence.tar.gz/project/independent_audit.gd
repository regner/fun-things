extends SceneTree
func _initialize() -> void:
 call_deferred("audit")
func audit() -> void:
 var scene: PackedScene = load("res://scenes/previews/weapons_smg/smg_wedgewire_a_game_camera.tscn")
 var view: Node3D = scene.instantiate()
 root.add_child(view)
 var camera: Camera3D = view.get_node("GameCamera")
 assert(is_equal_approx(camera.near, 0.1) and is_equal_approx(camera.far, 160.0))
 assert(camera.projection == Camera3D.PROJECTION_PERSPECTIVE)
 assert(camera.global_basis.z.is_equal_approx(Vector3.UP))
 assert(view.get_node("Weapon").position.is_equal_approx(Vector3(0, 1.3, 0)))
 assert(view.get_node("ReviewPad/Model").scene_file_path.ends_with("smg_wedgewire_review_pad.glb"))
 assert(view.get_node("ReviewPad/Model").transform.is_equal_approx(Transform3D.IDENTITY))
 var collisions: int = 0
 var meshes: int = 0
 for node: Node in view.find_children("*", "", true, false):
  assert(not node is CollisionObject3D and not node is CollisionShape3D)
  assert(not node is Skeleton3D and not node is AnimationPlayer)
  if node is MeshInstance3D:
   meshes += 1
   assert(node.mesh is ArrayMesh)
   assert(node.scale.is_equal_approx(Vector3.ONE))
 assert(meshes == 18)
 var rows: Array = []
 for file: String in ["res://scenes/prefabs/weapons_smg/smg_wedgewire_a.tscn", "res://scenes/previews/weapons_smg/smg_wedgewire_a_preview.tscn", "res://scenes/previews/weapons_smg/smg_wedgewire_a_game_camera.tscn"]:
  var loaded: PackedScene = ResourceLoader.load(file, "PackedScene", ResourceLoader.CACHE_MODE_IGNORE)
  var instance: Node = loaded.instantiate()
  assert(instance != null)
  var state: SceneState = loaded.get_state()
  rows.append({"path":file, "uid":ResourceUID.id_to_text(ResourceLoader.get_resource_uid(file)), "nodes":state.get_node_count(), "inherits":state.get_base_scene_state() != null})
  instance.free()
 print("INDEPENDENT_AUDIT ", JSON.stringify({"scene_ancestry":rows,"camera_near":camera.near,"camera_far":camera.far,"meshes":meshes}))
 view.free()
 quit()
