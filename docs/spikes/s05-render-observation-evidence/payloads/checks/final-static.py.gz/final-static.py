from pathlib import Path
import ast,hashlib,json,subprocess,time
run=Path('/tmp/s05-draw-8c398027-run01')
rows=[]
for p in sorted(Path('tools/s05_draw').glob('*.py')):
 ast.parse(p.read_text()); rows.append({'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'ast_ok':True})
commands=[['/home/regner/.local/share/mise/installs/github-atelico-gdstyle/0.3.0/gdstyle','fmt','--check','tests/fixtures/s05_draw/observer.gd'],['/home/regner/.local/share/mise/installs/github-atelico-gdstyle/0.3.0/gdstyle','--max-warnings','0','tests/fixtures/s05_draw/observer.gd'],['python','-B','tools/s05_draw/check.py','--group',str(run/'group02'),'--output',str(run/'final-static-observation.json')],['git','diff','--check']]
for i,args in enumerate(commands):
 start=time.time(); r=subprocess.run(args,capture_output=True)
 out=run/f'final-static-{i}.stdout'; err=run/f'final-static-{i}.stderr'
 out.write_bytes(r.stdout);err.write_bytes(r.stderr)
 rows.append({'argv':args,'exit':r.returncode,'start_unix':start,'end_unix':time.time(),'stdout':str(out),'stderr':str(err)})
 assert r.returncode==(1 if i==2 else 0)
record={'checks':rows,'original_runtime_suites_repeated':False}
(run/'final-static.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
