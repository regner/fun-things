from pathlib import Path
import gzip,json,hashlib,time
root=Path('docs/spikes/s05-saved-presentation-evidence/run04')
rows=[]
for p in sorted(root.glob('*.gz')):
 b=gzip.decompress(p.read_bytes()); rows.append({'path':str(p),'decoded_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 if '.request.json' in p.name or '.response.json' in p.name or p.name.endswith('.json.gz'):
  json.loads(b)
requests=[r for r in rows if '.request.json.gz' in r['path']]
responses=[r for r in rows if '.response.json.gz' in r['path']]
assert len(requests)==len(responses)==158
record={'complete_directory_set':rows,'sdk_request_pairs':len(requests),'sdk_response_pairs':len(responses),'readback_unix':time.time()}
Path('/tmp/s05-draw-8c398027-run01/old-run04-history.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'complete_decoded_payloads':len(rows),'sdk_pairs':len(requests)}))
