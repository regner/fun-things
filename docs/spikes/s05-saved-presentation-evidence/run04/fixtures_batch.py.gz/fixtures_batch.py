import sys,json
sys.path.insert(0,"/tmp/s05-author-56eb6b28-run04")
from call import call
base="res://tests/fixtures/s05_effect/"
def step(name,args=None):
 r=call(name,args)
 if r.get("isError"):raise RuntimeError(json.dumps(r))
 print(name,"ok",flush=True)
 return r
for variant in ["boot","burst"]:
 step("scene_create_inherited",{"file_path":base+variant+".tscn","base_scene":"res://tests/fixtures/s05/"+variant+".tscn"})
 step("scene_open",{"file_path":base+variant+".tscn"})
 for path,name in [(".","proof"),("View/Match","match"),("View/Match/Presentation","presentation")]:
  step("node_set_script",{"node_path":path,"script_path":base+name+".gd"})
 step("editor_save_scene")
 step("scene_create_node",{"class_name":"Node3D","parent_path":"View/Match/Presentation","node_name":"Slots"})
 step("editor_save_scene")
 step("scene_instantiate",{"parent_path":"View/Match/Presentation/Slots","scene_path":base+"explosion.tscn","instances":[{"name":"Slot"+str(i)} for i in range(8)]})
 step("editor_save_scene")
step("scene_create",{"file_path":base+"editor_harness.tscn","root_type":"Node","root_name":"S05EffectEditorHarness"})
step("scene_open",{"file_path":base+"editor_harness.tscn"})
step("node_set_script",{"node_path":".","script_path":base+"editor_probe.gd"})
step("editor_save_scene")
