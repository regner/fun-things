import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/tmp/s05-author-56eb6b28-run04')
from call import call
base='res://tests/fixtures/s05_effect/';project=Path('/tmp/s05-author-56eb6b28-run01/project')
def step(name,args=None):
 r=call(name,args)
 if r.get('isError'):raise RuntimeError(json.dumps(r))
 print(name,'ok',flush=True)
 return r
for name in ['editor_probe','presentation','match','proof']:
 step('script_check',{'file_path':base+name+'.gd'})
step('editor_refresh',{'file_paths':[base+n+'.tscn' for n in ['explosion','boot','burst','editor_harness']]})
step('editor_wait_for_idle',{'timeout_ms':10000})
receipts={}
for name in ['explosion','boot','burst','editor_harness']:
 path=base+name+'.tscn';disk=project/path[6:]
 before=disk.read_bytes()
 Path('/tmp/s05-author-56eb6b28-run04/roundtrip-before-'+name+'.tscn').write_bytes(before)
 step('scene_open',{'file_path':path})
 step('editor_save_scene')
 step('scene_close',{'file_path':path})
 step('scene_open',{'file_path':path})
 step('editor_save_scene')
 step('scene_close',{'file_path':path})
 step('scene_open',{'file_path':path})
 after=disk.read_bytes()
 receipts[name]={'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'same_bytes':before==after}
 Path('/tmp/s05-author-56eb6b28-run04/roundtrip-partial.json').write_text(json.dumps(receipts,indent=2)+'\n')
 if before!=after:print('canonicalized',name,flush=True)
step('scene_open',{'file_path':base+'editor_harness.tscn'})
for name in ['explosion','boot','burst']:
 receipts[name]['inspection']=step('node_call_method',{'node_path':'.','method_name':'inspect_scene','args':[base+name+'.tscn']})
receipts['context']=step('node_call_method',{'node_path':'.','method_name':'context'})
Path('/tmp/s05-author-56eb6b28-run04/roundtrip.json').write_text(json.dumps(receipts,indent=2)+'\n')
