import sys,json
from pathlib import Path
sys.path.insert(0,'/tmp/s05-author-56eb6b28-run04')
from call import call
base='res://tests/fixtures/s05_effect/'
def step(name,args=None):
 r=call(name,args)
 if r.get('isError'):raise RuntimeError(json.dumps(r))
 for b in r.get('content',[]):
  if b.get('type')=='text':
   d=json.loads(b['text'])
   if d.get('success') is False:raise RuntimeError(json.dumps(d))
 print(name,'ok',flush=True)
 return r
step('discover_tools',{'request':['scene_advanced','scene_inheritance','editor_advanced','cleanup'],'include_schemas':True})
for name in ['editor_probe','presentation','match','proof']:
 step('script_write',{'file_path':base+name+'.gd','content':Path('/tmp/s05-author-56eb6b28-run01/'+name+'.gd.draft').read_text()})
step('scene_open',{'file_path':base+'explosion.tscn'})
step('scene_create_node',{'class_name':'Node3D','parent_path':'.','node_name':'Visuals'})
step('editor_save_scene')
step('node_set_script',{'node_path':'.','script_path':base+'editor_probe.gd'})
step('editor_save_scene')
step('scene_close',{'file_path':base+'explosion.tscn'})
step('scene_open',{'file_path':base+'explosion.tscn'})
print(step('node_call_method',{'node_path':'.','method_name':'link_model'}),flush=True)
step('editor_save_scene')
step('node_set_script',{'node_path':'.','script_path':''})
step('node_set_property',{'node_path':'.','property':'visible','value':False})
step('editor_save_scene')
