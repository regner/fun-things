"""Independent exact-candidate preservation, retention and vertex geometry audit."""
import hashlib,json,math,pathlib,struct,subprocess
ROOT=pathlib.Path('/home/regner/.paseo/worktrees/0u71f39f/s06-provisional-turn-seam')
OUT=pathlib.Path('/tmp/s06-independent-review')
BASE='6c36c1232cc2403b6cbac03248ac28006bc83bd9'
ORIGINAL='096469f25db2617858d49f88860991c1c84c222e'
CANDIDATE='bb7e902c1a663cfddf337cebda82fae326cb5e6d'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def tree(ref):
    result={}
    for row in git('ls-tree','-rz',ref).split(b'\0'):
        if row:
            meta,name=row.split(b'\t');result[name.decode()]=meta.decode().split()[2]
    return result
def glb(path):
    data=path.read_bytes();size,kind=struct.unpack_from('<II',data,12)
    doc=json.loads(data[20:20+size]);off=20+size;length,kind=struct.unpack_from('<II',data,off)
    binary=data[off+8:off+8+length];rows=[]
    for node in doc['nodes']:
        if 'mesh' not in node: continue
        assert node.get('rotation',[0,0,0,1])==[0,0,0,1]
        assert node.get('scale',[1,1,1])==[1,1,1]
        translate=node.get('translation',[0,0,0]);points=[]
        for primitive in doc['meshes'][node['mesh']]['primitives']:
            a=doc['accessors'][primitive['attributes']['POSITION']];v=doc['bufferViews'][a['bufferView']]
            assert a['componentType']==5126 and a['type']=='VEC3'
            start=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',12)
            for i in range(a['count']):
                p=struct.unpack_from('<fff',binary,start+i*stride)
                points.append([p[k]+translate[k] for k in range(3)])
        minimum=[min(p[k] for p in points) for k in range(3)]
        maximum=[max(p[k] for p in points) for k in range(3)]
        rows.append({'name':node['name'],'minimum':minimum,'maximum':maximum,'vertices':len(points)})
    return rows
def main():
    candidate,base,original=map(tree,[CANDIDATE,BASE,ORIGINAL])
    changed=[p for p in base if base[p]!=candidate.get(p)]
    assert changed==['TODO.md'],changed
    accepted_delta=[p for p in original if original[p]!=base.get(p)]
    assert all(p.endswith('.md') for p in accepted_delta),accepted_delta
    report={'candidate':CANDIDATE,'accepted_base':BASE,'original_base':ORIGINAL,
            'existing_base_files':len(base),'changed_existing_base_files':changed,
            'accepted_docs_delta':accepted_delta,'original_files':len(original),
            'added_candidate_paths':sorted(set(candidate)-set(base)),'checks':[]}
    fp=json.loads((ROOT/'docs/spikes/s06-evidence/final-source-fingerprints.json').read_text())
    assert all(sha(ROOT/p)==h for p,h in fp.items());report['final_fingerprints_verified']=len(fp)
    evidence=ROOT/'docs/spikes/s06-evidence';manifest=json.loads((evidence/'manifest.json').read_text())
    for row in manifest['artifacts']:
        p=evidence/row['artifact'];assert p.is_file(),p
        assert len(p.read_bytes())==row['bytes'] and sha(p)==row['sha256'],p
    report['retained_manifest_verified']=len(manifest['artifacts'])
    report['retained_manifest_unlisted_files']=sorted(str(p.relative_to(evidence)) for p in evidence.rglob('*') if p.is_file() and str(p.relative_to(evidence)) not in {r['artifact'] for r in manifest['artifacts']})
    for run in ['s06-host-first','s06-host-final','s06-content-final']:
        d=json.loads((evidence/run/'summary.json').read_text())
        report[run]={'changed_from_final':{p:{'tested':h,'candidate':sha(ROOT/p)} for p,h in d['source_fingerprints'].items() if sha(ROOT/p)!=h},'import':d['import'],'outcomes':d['outcomes']}
    before=json.loads((evidence/'operations/roundtrip-final-before.json').read_text())
    after=json.loads((evidence/'operations/roundtrip-final-after.json').read_text())
    assert before==after and all(sha(ROOT/p)==h for p,h in after.items())
    report['supplied_live_roundtrip_current_files']=len(after)
    rows=[]
    for side in ['west','east']:
        mesh=glb(ROOT/f'art/models/spikes/s06_{side}.glb');assert len(mesh)==17
        for r in mesh:
            assert (r['maximum'][0]<=1e-6 if side=='west' else r['minimum'][0]>=-1e-6)
        rows+=mesh
    result=json.loads((OUT/'engine/project/s06-result.json').read_text())
    for row in result['geometry']:
        raw=next(r for r in rows if r['name']==row['name'])
        assert max(abs(raw['minimum'][k]-row['minimum'][k]) for k in range(3))<1e-5
        assert max(abs(raw['maximum'][k]-raw['minimum'][k]-row['size'][k]) for k in range(3))<1e-5
    report['glb_vertex_bounds']=rows
    report['engine_geometry_matches_glb_vertices']=len(result['geometry'])
    report['working_tree_status']=git('status','--porcelain=v1').decode();assert not report['working_tree_status']
    (OUT/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['added_candidate_paths','glb_vertex_bounds']},indent=2))
if __name__=='__main__': main()
