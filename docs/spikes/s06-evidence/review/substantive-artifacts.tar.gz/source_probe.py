"""Read committed Blender geometry; export only scratch outputs, without source saves."""
import bpy,json,pathlib,runpy,sys
ROOT=pathlib.Path('/home/regner/.paseo/worktrees/0u71f39f/s06-provisional-turn-seam')
OUT=pathlib.Path('/tmp/s06-independent-review')
objects=[]
for name in ['export_s06_west','export_s06_east']:
    col=bpy.data.collections[name]
    for obj in col.all_objects:
        coords=[obj.matrix_world@v.co for v in obj.data.vertices]
        # Blender X,Y,Z converts to Godot X,Z,-Y.
        points=[(p.x,p.z,-p.y) for p in coords]
        objects.append({'collection':name,'name':obj.name,'minimum':[min(p[k] for p in points) for k in range(3)],
                        'maximum':[max(p[k] for p in points) for k in range(3)],'scale':list(obj.scale),
                        'rotation':list(obj.rotation_euler),'vertices':len(obj.data.vertices),
                        'triangles':len(obj.data.polygons),'materials':[s.name for s in obj.data.materials]})
report={'version':bpy.app.version_string,'build_hash':bpy.app.build_hash.decode(),'source':bpy.data.filepath,
        'unit_scale':bpy.context.scene.unit_settings.scale_length,'objects':objects}
(OUT/'source-probe.json').write_text(json.dumps(report,indent=2)+'\n')
assert len(objects)==34
sys.argv=['source_probe','--',str(OUT/'reexport')]
runpy.run_path(str(ROOT/'tools/s06/export.py'),run_name='__main__')
print('INDEPENDENT_SOURCE_PROBE_COMPLETE')
