extends SceneTree
## Independent bounded content and ownership counterexamples in a private CLI copy.

var checks: Array[Dictionary] = []


## Installs the saved fixture once and runs non-trajectory boundary checks.
func _initialize() -> void:
	_run.call_deferred()


## Captures public API results without rewriting the candidate's saved files.
func _run() -> void:
	var fixture: S06Fixture = load("res://tests/fixtures/s06/intersection.tscn").instantiate()
	root.add_child(fixture)
	await process_frame
	var city: S06City = fixture.get_node("City")
	_record("baseline", city.validate_content(), "OK")
	var original: S06Bake = city.derived
	var link: S06Link = city.get_node("Sectors/West/Topology/RoadWestLink")
	var curve: Curve3D = link.curve
	link.curve = curve.duplicate()
	link.curve.add_point(Vector3(1000, 0, 0))
	_record("over128m curve bake", city.bake_content() == null, true)
	link.curve = curve.duplicate()
	for i: int in range(15):
		link.curve.add_point(Vector3.ZERO)
	_record("over16 controls bake", city.bake_content() == null, true)
	link.curve = curve.duplicate()
	link.curve.set_point_out(0, Vector3(INF, 0, 0))
	_record("nonfinite control bake", city.bake_content() == null, true)
	link.curve = curve
	var anchors: Array[Node] = []
	for i: int in range(65):
		var anchor: S06Anchor = S06Anchor.new()
		anchor.world_id = StringName("review/anchor/%d" % i)
		city.add_child(anchor)
		anchors.append(anchor)
	_record("over64 anchors bake", city.bake_content() == null, true)
	for anchor: Node in anchors:
		city.remove_child(anchor)
		anchor.free()
	var extras: Array[Node] = []
	for i: int in range(129):
		var extra: S06Link = S06Link.new()
		extra.world_id = StringName("review/link/%d" % i)
		extra.from_id = link.from_id
		extra.to_id = link.to_id
		extra.kind = link.kind
		extra.width_m = 9.0
		extra.curve = curve
		city.add_child(extra)
		extras.append(extra)
	_record("over128 links bake", city.bake_content() == null, true)
	for extra: Node in extras:
		city.remove_child(extra)
		extra.free()
	var width: float = link.width_m
	link.width_m = INF
	var invalid_bake: S06Bake = city.bake_content()
	_record("nonfinite width bake refused", invalid_bake == null, true)
	if invalid_bake != null:
		city.derived = invalid_bake
		_record("nonfinite width public map refused", city.map_data().code, "CONTENT_INVALID")
		_record("nonfinite width public route refused", city.route("FOOT",
			&"s06/foot/west", &"s06/foot/east").code, "CONTENT_INVALID")
	link.width_m = width
	city.derived = original
	_record("restored", city.validate_content(), "OK")
	var f: FileAccess = FileAccess.open("res://review-boundary.json", FileAccess.WRITE)
	f.store_string(JSON.stringify(checks, "\t") + "\n")
	f.close()
	fixture.queue_free()
	await process_frame
	print("INDEPENDENT_BOUNDARY_RESULT ", JSON.stringify(checks))
	quit()


## Retains unexpected results as findings candidates instead of weakening expectations.
func _record(label: String, actual: Variant, expected: Variant) -> void:
	checks.append({"label": label, "actual": actual, "expected": expected,
		"passed": actual == expected})
