"""Enumerate all substantive review outputs, independent sources and full original evidence refs."""
import hashlib,json,pathlib
from audit import ROOT,OUT,CANDIDATE,BASE,ORIGINAL
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def entry(p,relative=True):
    return {'path':str(p.relative_to(OUT) if relative else p.relative_to(ROOT)),
            'bytes':p.stat().st_size,'sha256':sha(p)}
session=pathlib.Path((OUT/'session-path.stdout').read_text().strip())
calls=[]
for raw in session.read_text().splitlines():
    row=json.loads(raw);payload=row.get('payload',{})
    if row.get('type')=='response_item' and payload.get('type') in ['function_call','function_call_output']:
        calls.append(row)
(OUT/'review-tool-history.json').write_text(json.dumps({'provider_session':str(session),'raw_tool_calls_and_outputs':calls},indent=2)+'\n')
existing=json.loads((ROOT/'docs/spikes/s06-evidence/manifest.json').read_text())
substantive_project_outputs={'engine/project/s06-result.json','engine/project/s06-changed.tscn',
                            'engine/project/s06-rebaked.tres','engine/project/review-boundary.json',
                            'engine/project/review_boundary.gd'}
excluded_prefixes=['engine/project/','content-sandbox/project/','scripts/compiler-project/',
                   'engine/user/','content-sandbox/user/','scripts/compiler-user/',
                   'boundary-user/','blender-user/','__pycache__/']
files=[]
for p in sorted(OUT.rglob('*')):
    if not p.is_file():continue
    relative=str(p.relative_to(OUT))
    if relative in ['manifest.json','handoff-hashes.json']:continue
    if relative not in substantive_project_outputs and any(relative.startswith(s) for s in excluded_prefixes):continue
    files.append(entry(p))
consulted=json.loads((OUT/'consulted-paths.json').read_text())
consulted=[p for p in consulted if (ROOT/p).is_file()]
consulted+=['docs/spikes/s04-contracts.md','docs/spikes/s05-contracts.md','docs/spikes/s06.md',
            'docs/spikes/s06-contracts.md','docs/spikes/s06-source-handoff.md',
            'docs/spikes/s06-evidence/raw-task.txt','docs/spikes/s06-evidence/raw-s06-todo.md',
            'docs/spikes/s06-evidence/manifest.json','docs/spikes/s06-evidence/README.md',
            'tests/fixtures/s02/actor_motion.gd','tests/fixtures/s02/actor.tscn',
            'tests/fixtures/s04/kinematic.gd','tests/fixtures/s04/kinematic.tscn',
            'tests/fixtures/s04/drive_rules.gd','tools/script_checks.py',
            'mise.toml','gdstyle.toml','.gdstyle-version']
consulted+=json.loads((OUT/'scripts/scripts.json').read_text())
consulted+=list(json.loads((ROOT/'docs/spikes/s06-evidence/final-source-fingerprints.json').read_text()))
manifest={'reviewer':'0f8ba889-b2e4-47be-bcbb-6c8ccf23cf76','candidate':CANDIDATE,
          'accepted_base':BASE,'original_base':ORIGINAL,'verdict':'REQUEST CHANGES',
          'local_artifacts':files,'candidate_consulted_files':[entry(ROOT/p,False) for p in sorted(set(consulted))],
          'candidate_evidence_root':'docs/spikes/s06-evidence',
          'complete_existing_candidate_evidence_manifest':existing,
          'existing359_entries_policy':'Preserved in full with original input/artifact/bytes/hash values; independently verified against exact candidate. No filtering.',
          'additional_original_task':entry(ROOT/'docs/spikes/s06-evidence/raw-s06-todo.md',False),
          'omitted_redundant_staging_prefixes':excluded_prefixes,
          'staging_identity':'Immutable dependencies are exact candidate Git refs; per-run source_fingerprints in full summaries and current38-file ledger bind tested inputs. All substantive generated results/counterexamples/probe sources are included explicitly.',
          'failures':{'content-sandbox':'exit1 socket/listen denial; no outcome',
                      'boundary':'process exit0;3 semantic expectations fail nonfinite width R1',
                      'source-probe':'exit124 owned50s timeout after completed extraction/export; sandbox audio teardown',
                      'exploratory_reads':'Full path-mistake/tool-returned history preserved; user corrected raw TODO path. No candidate defect inferred from guessed S04/.godot-version filenames.',
                      'retention-first-readback':'Reviewer initial manifest indexed redirected retention.stdout while command still writing it, causing one mismatch. Full initial manifest/receipt/readback failure retained. Corrected final manifest is generated after those outputs settle; final run prints to tool output only.'},
          'report':'report.md','final_followup':'Same reviewer explicit exact FINAL required after fixes/retention; no unchanged technical rerun required for docs-only retention/rebase.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
readback=json.loads((OUT/'manifest.json').read_text())
assert readback['complete_existing_candidate_evidence_manifest']==existing
for row in readback['local_artifacts']:
    p=OUT/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],p
for row in readback['candidate_consulted_files']:
    p=ROOT/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],p
hashes={'candidate':CANDIDATE,'report':entry(OUT/'report.md'),'manifest':entry(OUT/'manifest.json'),
        'all_local_and_candidate_hashes_readback_verified':True,'local_artifact_count':len(files),
        'complete_existing_evidence_entries':len(existing['artifacts'])}
(OUT/'handoff-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps(hashes,indent=2))
