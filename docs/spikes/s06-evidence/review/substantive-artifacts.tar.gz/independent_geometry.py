"""Compare actual poses to direct GLB vertex bounds, without importing the lead analyzer."""
import json,math,pathlib
from audit import glb,ROOT,OUT
def rect(r):return (r['minimum'][0],r['minimum'][2],r['maximum'][0],r['maximum'][2])
def inside(p,rs):return any(r[0]-1e-6<=p[0]<=r[2]+1e-6 and r[1]-1e-6<=p[1]<=r[3]+1e-6 for r in rs)
def main():
    rows=glb(ROOT/'art/models/spikes/s06_west.glb')+glb(ROOT/'art/models/spikes/s06_east.glb')
    road=[rect(r) for r in rows if r['name'].startswith('Road')]
    walk=[rect(r) for r in rows if r['name'].startswith('Walk')]
    markings=[r for r in rows if r['name'].startswith('Crossing')]
    # Source stripes determine crossing Z extent; the carriageway determines crossing X extent.
    crossing=(-4.5,min(r['minimum'][2] for r in markings),4.5,max(r['maximum'][2] for r in markings))
    walk.append(crossing)
    data=json.loads((OUT/'engine/project/s06-result.json').read_text());metrics={};failures=[]
    expected={'foot':([20,.001,6.5],-.5*math.pi,1200),
              'east_to_north':([2.25,0,-20],0,1800),
              'west_to_south':([-2.25,0,20],math.pi,1800)}
    for name,trajectory in data['trajectories'].items():
        outside=contacts=seams=0;maximum=0;route_error=0;prev=None;samples=0
        for pose in trajectory:
            x,_,z=pose['position'];yaw=pose['yaw']
            if prev:
                maximum=max(maximum,math.dist(pose['position'],prev['position']))
                seams+=(x<0)!=(prev['position'][0]<0)
            prev=pose;contacts+=len(pose['contacts'])
            distances=[]
            for a,b in zip(data['routes'][name],data['routes'][name][1:]):
                vx,vz=b[0]-a[0],b[2]-a[2];dot=(x-a[0])*vx+(z-a[2])*vz
                length2=vx*vx+vz*vz
                if dot<=0: distances.append(math.hypot(x-a[0],z-a[2]))
                elif dot>=length2: distances.append(math.hypot(x-b[0],z-b[2]))
                else: distances.append(abs(vx*(z-a[2])-vz*(x-a[0]))/math.sqrt(length2))
            route_error=max(route_error,min(distances))
            if name=='foot':
                footprint=[(x+.38*math.cos(i*math.tau/360),z+.38*math.sin(i*math.tau/360)) for i in range(360)]
                regions=walk
            else:
                # Dense complete collider footprint, including interior: rectangle-union hole checks.
                footprint=[]
                for a in range(19):
                    for b in range(35):
                        side=-.9+a*.1;forward=-1.7+b*.1
                        footprint.append((x+math.cos(yaw)*side-math.sin(yaw)*forward,
                                          z-math.sin(yaw)*side-math.cos(yaw)*forward))
                regions=road
            samples+=len(footprint);outside+=sum(not inside(p,regions) for p in footprint)
        target,yaw,limit=expected[name];last=trajectory[-1]
        error=math.dist(last['position'],target)
        heading=abs((last['yaw']-yaw+math.pi)%math.tau-math.pi)
        # Lane expectations are literal road quadrants/directions, independent of route construction.
        if name=='east_to_north':
            approach=all(p['position'][2]>0 and math.cos(p['yaw']+math.pi/2)>.9 for p in trajectory if p['position'][0]<-10)
            exit=all(p['position'][0]>0 and math.cos(p['yaw'])>.9 for p in trajectory if p['position'][2]<-10)
        elif name=='west_to_south':
            approach=all(p['position'][2]<0 and math.cos(p['yaw']-math.pi/2)>.9 for p in trajectory if p['position'][0]>10)
            exit=all(p['position'][0]<0 and math.cos(p['yaw']-math.pi)>.9 for p in trajectory if p['position'][2]>10)
        else: approach=exit=True
        metrics[name]={'ticks':len(trajectory),'seconds':sum(p['delta'] for p in trajectory),
                       'destination_error_m':error,'heading_error_degrees':math.degrees(heading),
                       'dense_footprint_samples':samples,'outside':outside,'contacts':contacts,
                       'seam_crossings':seams,'max_step_m':maximum,'max_route_error_m':route_error,'legal_approach':approach,'legal_exit':exit}
        if outside or contacts or seams!=1 or route_error>1 or error>(.5 if name=='foot' else .75) or heading>math.radians(10) or len(trajectory)>limit or not approach or not exit:
            failures.append(name)
    # Check all map segments against direct geometry, endpoints in four literal cardinal arms.
    ends={'west_link':(-24,0),'east_link':(24,0),'north_link':(0,-24),'south_link':(0,24)}
    maps={}
    for r in data['roads']:
        key=r['id'].split('/')[-1];first,last=r['points'][0],r['points'][-1]
        end=first if key=='west_link' else last;expected_end=ends[key]
        e=math.hypot(end[0]-expected_end[0],end[2]-expected_end[1])
        assert e<.01 and r['width_m']==9 and all(inside((p[0],p[2]),road) for p in r['points'])
        maps[key]={'endpoint_error_m':e,'pixel_endpoint':[80+3*end[0],80+3*end[2]],'width_px':r['width_m']*3}
    report={'failures':failures,'metrics':metrics,'crossing_from_source':crossing,'map':maps,
            'scope':'Discrete 60Hz actual engine poses; dense solid footprint samples; no analytic swept-volume or drawn/runtime feel certification.'}
    (OUT/'independent-geometry.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert not failures
if __name__=='__main__':main()
