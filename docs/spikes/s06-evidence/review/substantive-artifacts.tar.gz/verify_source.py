"""Bind independent actual Blender extraction and scratch exports to committed GLB vertices."""
import hashlib,json
from audit import ROOT,OUT,glb
s=json.loads((OUT/'source-probe.json').read_text());checks=[]
for row in s['objects']:
    side=row['collection'].split('_')[-1]
    raw=next(g for g in glb(ROOT/f'art/models/spikes/s06_{side}.glb') if g['name']==row['name'])
    err=max(abs(row[key][k]-raw[key][k]) for key in ['minimum','maximum'] for k in range(3))
    assert err<1e-6,(row['name'],err)
    checks.append({'object':row['name'],'bound_error_m':err})
for side in ['west','east']:
    a=ROOT/f'art/models/spikes/s06_{side}.glb';b=OUT/f'reexport/s06_{side}.glb'
    assert a.read_bytes()==b.read_bytes()
res={'source_bounds_vs_glb':checks,'reexports_equal':{side:hashlib.sha256((OUT/f'reexport/s06_{side}.glb').read_bytes()).hexdigest() for side in ['west','east']},
     'cli_exit':int((OUT/'source-probe.exit').read_text()),
     'limit':'Geometry extraction/export completed, sandbox audio teardown hung until owned timeout; invocation is not clean exit pass.'}
(OUT/'source-verification.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res,indent=2))
