from pathlib import Path
import gzip, hashlib, json, re, subprocess

ROOT = Path('/tmp/s05-independent-review')
REPO = Path('/home/regner/.paseo/worktrees/0u71f39f/s05-authoritative-chain-fixture')
EVIDENCE = ROOT / 'docs/spikes/s05-evidence'
SHA = 'f7883c332a3728267afc86343d6e0f8dc696ede6'
BASE = 'c8096b55ef97412552366fdaa74c220b976ed82e'
digest = lambda b: hashlib.sha256(b).hexdigest()
manifest = json.loads((EVIDENCE / 'retention.json').read_text())
failures, verified, logs, bindings = [], [], [], {}
for row in manifest:
    p = EVIDENCE / row['path']
    b = p.read_bytes()
    raw = gzip.decompress(b) if row['gzip'] else b
    checks = {'stored_bytes':len(b)==row['stored_bytes'],
              'stored_sha256':digest(b)==row['stored_sha256'],
              'raw_bytes':len(raw)==row['raw_bytes'],
              'raw_sha256':digest(raw)==row['raw_sha256']}
    verified.append({'path':row['path'],'checks':checks})
    if not all(checks.values()): failures.append(row['path'])
    if '.log' in p.name or p.name.endswith('.txt'):
        s = raw.decode(errors='replace')
        diagnostics = [line for line in s.splitlines()
                       if re.search(r'SCRIPT ERROR:|ERROR:|WARNING:|Traceback|S05 .*"event":"failure"',line)]
        logs.append({'path':row['path'],'raw_bytes':len(raw),'diagnostics':diagnostics})
for name in ['canonical','queue-corrected','queue-pressure','initial-host-pass']:
    data = json.loads((EVIDENCE/name/'result.json').read_text())
    diffs = []
    for relative, expected in data.get('source_sha256',{}).items():
        p = ROOT / relative
        if p.is_file() and digest(p.read_bytes()) != expected:
            diffs.append(relative)
    bindings[name] = {'ok':data['ok'],'mismatched_candidate_sources':diffs,
                      'saved_source_unchanged':data.get('saved_source_unchanged')}
changed = subprocess.check_output(['git','diff','--name-status',BASE,SHA],cwd=REPO,text=True)
outside = []
for line in changed.splitlines():
    status,path = line.split('\t',1)
    if not (path=='TODO.md' or path.startswith(('tests/fixtures/s05/','tools/s05/',
                  'docs/spikes/s05')) or path=='tools/run_s05.py'):
        outside.append(line)
unchanged_original = []
for path in subprocess.check_output(['git','ls-tree','-r','--name-only',BASE],cwd=REPO,text=True).splitlines():
    if path=='TODO.md': continue
    b=subprocess.check_output(['git','show',BASE+':'+path],cwd=REPO)
    if (ROOT/path).read_bytes()!=b: failures.append('base content changed '+path)
    unchanged_original.append({'path':path,'sha256':digest(b)})
raw_task = subprocess.check_output(['git','show','c0eda26f7f010af75bbf10c272ec5cb001442331:TODO.md'],cwd=REPO,text=True)
block = raw_task[raw_task.index('- [ ] **S05'):raw_task.index('- [ ] **S06')]
raw_task_equal = block == (EVIDENCE/'raw-s05-todo.md').read_text()
roundtrip = json.loads((EVIDENCE/'editor/roundtrip-summary.json').read_text())
roundtrip_final_binding = {p:digest((ROOT/p).read_bytes())==h for p,h in roundtrip['after'].items()}
data={'candidate':SHA,'base':BASE,'retained_artifacts':len(manifest),
      'hash_failures':failures,'scope_outside':outside,'raw_todo_exact':raw_task_equal,
      'source_binding':bindings,'roundtrip_final_binding':roundtrip_final_binding,
      'unchanged_original_files':unchanged_original,'artifact_checks':verified,
      'log_inventory':logs}
(ROOT/'evidence-audit.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:v for k,v in data.items() if k not in ['artifact_checks','log_inventory','unchanged_original_files']},indent=2))
print('unchanged base files',len(unchanged_original),'logs examined',len(logs))
for row in logs:
    if row['diagnostics']: print(json.dumps(row))
