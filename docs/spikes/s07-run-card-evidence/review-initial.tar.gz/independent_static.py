import hashlib
import json
import math
from pathlib import Path
import re
import struct
import subprocess

REPO = Path('/home/regner/.paseo/worktrees/0u71f39f/s07-content-inventory-run-cards')
OUT = Path('/tmp/s07-independent-review')
BASE = '48aef3dbd133876743f504f94a1b788a26d5638f'
HEAD = '1ba0f189193f31d48ab39c3c3fc4e555089fc48b'
E = REPO / 'docs/spikes/s07-run-card-evidence'
inventory = json.loads((E / 'inventory.json').read_bytes())
assert (E / 'inventory.json').read_bytes() == (OUT / 'reproduced-inventory.json').read_bytes()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('merge-base', BASE, HEAD).decode().strip() == BASE
assert not git('status', '--porcelain=v1')
changed = set(git('diff', '--name-only', BASE, HEAD).decode().splitlines())
expected = set(json.loads((E / 'expected-set.json').read_bytes()))
assert changed == expected | {'docs/spikes/s07-run-card-evidence/manifest.json'}
manifest = json.loads((E / 'manifest.json').read_bytes())
assert set(manifest['payloads']) == expected
actual = {str(p.relative_to(REPO)) for p in E.rglob('*') if p.is_file()}
assert actual | {'TODO.md', 'tools/s07/inventory.py', 'docs/spikes/s07-run-cards.md'} == changed
for p, row in manifest['payloads'].items():
    data = (REPO / p).read_bytes()
    assert data == git('show', HEAD + ':' + p)
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
preserved = 0
for p in git('ls-tree', '-r', '--name-only', BASE).decode().splitlines():
    if p == 'TODO.md':
        continue
    assert git('rev-parse', BASE + ':' + p) == git('rev-parse', HEAD + ':' + p), p
    preserved += 1
before = git('show', BASE + ':TODO.md').decode()
after = (REPO / 'TODO.md').read_text()
task_pattern = r'^- \[ \] \*\*(.+?)\*\*'
assert re.findall(task_pattern, before, re.M) == re.findall(task_pattern, after, re.M)
assert len(re.findall(task_pattern, after, re.M)) == 27
print('PASS immutable original blobs', preserved, 'exact package paths', len(changed), '27 task identities')

# Independently decode binary index/position accessors, rather than trusting metadata counts.
model_expectations = {
    's02_ground': (376,2), 's02_low': (752,4), 's02_near': (2632,4),
    's02_tall': (3384,4), 's02_actor': (1316,3), 's02_target': (376,2),
    's02_pistol': (376,2), 's02_smg': (564,3), 's02_launcher': (564,3),
    's04_car': (1504,4), 's04_track': (1128,4),
    's05_explosion_carrier': (1344,3), 's06_west': (204,4), 's06_east': (204,4),
}
assert {Path(p).stem for p in inventory['models']} == set(model_expectations)
for p in sorted(inventory['models']):
    data = (REPO / p).read_bytes()
    magic, version, total = struct.unpack_from('<4sII', data)
    assert magic == b'glTF' and version == 2 and total == len(data)
    chunks = []; cursor = 12
    while cursor < len(data):
        length, kind = struct.unpack_from('<I4s', data, cursor)
        assert length % 4 == 0 and cursor + 8 + length <= total
        chunks.append((kind, data[cursor+8:cursor+8+length])); cursor += 8 + length
    assert cursor == total and [x[0] for x in chunks] == [b'JSON', b'BIN\0']
    g = json.loads(chunks[0][1]); binary = chunks[1][1]
    assert g['asset']['version'] == '2.0' and len(g['buffers']) == 1
    assert 'uri' not in g['buffers'][0] and len(binary) - g['buffers'][0]['byteLength'] in range(4)
    def accessor(index):
        a = g['accessors'][index]; v = g['bufferViews'][a['bufferView']]
        assert v['buffer'] == 0 and 'sparse' not in a
        fmt, size = {5121: ('B',1),5123: ('H',2),5125: ('I',4),5126: ('f',4)}[a['componentType']]
        width = {'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
        stride = v.get('byteStride', size * width); offset = a.get('byteOffset',0)
        assert offset + (a['count']-1)*stride + size*width <= v['byteLength']
        start = v.get('byteOffset',0)+offset
        assert v.get('byteOffset',0)+v['byteLength'] <= g['buffers'][0]['byteLength']
        return [struct.unpack_from('<'+fmt*width,binary,start+i*stride) for i in range(a['count'])]
    triangles = []
    for mesh in g['meshes']:
        count = 0
        for prim in mesh['primitives']:
            assert prim.get('mode',4) == 4
            positions = accessor(prim['attributes']['POSITION'])
            assert g['accessors'][prim['attributes']['POSITION']]['componentType'] == 5126
            assert all(math.isfinite(x) for row in positions for x in row)
            indexes = accessor(prim['indices'])
            assert len(indexes) % 3 == 0 and all(0 <= x[0] < len(positions) for x in indexes)
            assert 0 <= prim['material'] < len(g['materials'])
            count += len(indexes) // 3
        triangles.append(count)
    total_triangles = sum(triangles[n['mesh']] for n in g['nodes'] if 'mesh' in n)
    assert (total_triangles,len(g['materials'])) == model_expectations[Path(p).stem]
    assert total_triangles == inventory['models'][p]['triangles_mesh_nodes']
    assert not any(g.get(k) for k in ('images','textures','skins','animations','extensionsUsed'))
    mapping = inventory['models'][p]
    assert sorted(n['name'] for n in g['nodes']) == sorted(mapping['members'])
    imported = (REPO / (p+'.import')).read_text()
    assert f'source_file="res://{p}"' in imported
    assert mapping['uid'] in imported
    if Path(p).stem == 's05_explosion_carrier':
        assert [m['name'] for m in g['materials']] == ['flash_amber','burst_coral','flash_ivory']
        assert all(m.get('alphaMode','OPAQUE') == 'OPAQUE' and m['doubleSided'] for m in g['materials'])
    print('PASS binary',Path(p).name,'triangles',total_triangles,'materials',len(g['materials']))
print('PASS reproduced bytes, full package hash/readback, original blobs, binary GLB schema/index ranges/membership')
