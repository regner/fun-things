# Independent S07 exact-candidate review

Disposition: **REQUEST CHANGES — one P2 documentation/entry-gate finding.** The
static inventory, saved-input accounting and scoped evidence package otherwise pass
this focused review. No gameplay/resource change is requested or authorized.

Reviewed candidate: `1ba0f189193f31d48ab39c3c3fc4e555089fc48b`.
Accepted base: `48aef3dbd133876743f504f94a1b788a26d5638f`.
Workspace: `wks_17c8eacf90cb0832`; actual Git branch:
`s07-content-inventory-run-cards`; repository:
`/home/regner/.paseo/worktrees/0u71f39f/s07-content-inventory-run-cards`.
The workspace token appended to the branch in the launch text is workspace context;
the actual branch name above agrees with the raw brief and launch receipt.

Reviewer: `cdc5d0fa-3765-402d-bf3d-7e9f2ab3d4a4`, fresh independent context.
Effective settings verified once through Paseo get_agent_status:
codex/gpt-6.1-sol, configured/effective HIGH, auto-review, plan_mode false.
The complete returned settings are in `effective-settings.json`. ROOT's supplied
launch receipt was used; no profile/model inventory was repeated. Direct review,
no delegation. One focused static pass within the commissioned 20-minute limit.

## Finding

**P2 — Make a repeatable S06 route driver an explicit primary T entry gate.**
Location: `docs/spikes/s07-run-cards.md:162`, with the missing gate at line176.
The T primary recipe instructs the worker to neutralize/reset through accepted APIs
between routes and repeat the foot/car route order throughout the 600-second
measurement interval. The existing accepted S06 API cannot perform that reset:

- `tests/fixtures/s06/fixture.gd:73` calls stop_route, binds the same route, enables
  the selected body and clears the sample counters. It does not restore a body pose.
- `fixture.gd:125` neutralizes velocity and disables collision/commands; it preserves
  position and yaw. The S02 foot body's public neutralize API also only clears velocity
  (`tests/fixtures/s02/actor_motion.gd:32`).
- After a successful traversal, the body is at the route destination. On the next
  call, `tests/fixtures/s06/controller.gd:40` detects that destination and returns
  done immediately. The retained proof (`tests/fixtures/s06/proof.gd:154`) runs each
  route exactly once; it supplies no sustained repeat/reset receipt.

Thus following the named existing APIs produces one traversal per body followed by
empty completions, rather than the declared repeated movement load. Hardware and
drawability alone do not make the primary recipe ready. This violates the commission's
concrete-input and explicit-blocked-entry requirements and the existing S07 method's
repeatable route/schedule accounting. It is a gap in the new run card, not a defect
request against the accepted finite S06 fixture.

Action: replace the implication that an accepted primary reset exists with an
explicit missing prerequisite. Require an accepted, separately authorized sustained
route/reset driver before T primary launch, restoring the saved starting poses and
neutral state between repetitions and retaining evidence that repeated traversals
produce real samples/outcomes. If that later owner uses saved-scene reload instead,
name it explicitly and keep reload/loading/lifetime measurements distinct from the
normal traversal interval. Keep T BLOCKED pending that input. Mirror the already
correct comparator reset/event-driver gate at lines169–173. Resolve this review with
a concise documentation change; do not author a runtime driver or edit fixtures here.
Full numbered source evidence is retained in `checks/route-repeat-evidence.stdout`.

## Scope and evidence assessment

Read the raw commission and all steering, evidence index and actual owned files;
accepted-base AGENTS, orchestrator skill and reviewer/implementer contracts; original
52941da S07 TODO, actual 52941da→48aef3d cleanup and accepted S07 TODO; complete S07
method/prerequisite supplements; relevant design, asset/source, scene/identity,
topology and multiplayer ownership contracts. The S05 a15 acceptance comes from the
commission; historical pending language was not treated as a competing verdict.

Actual saved S02/S04/S05/S05-effect/S06 scenes and resource relationships were read,
including inherited camera overrides, S03 scaffold dependencies, S05 car/C-position
overrides, eight hidden linked effect slots, S06 identity sector instances, collision
shapes, topology anchors/curves and the saved derived fingerprint. Accepted source
handoffs/membership records and source/export evidence fingerprints were inspected.
Binary GLBs/import sidecars and committed source bytes were checked offline.

Inventory reproduction is byte-identical: 186 immutable inputs, 14 GLBs, 33 saved
scenes/resources and 11 compositions. Documented placement sets, triangle totals,
material counts and camera values agree with actual saved inputs. Independently
decoded GLB binary chunks and position/index accessors confirm finite positions,
accessor/buffer bounds, valid vertex/material indexes, triangle primitive counts,
mesh-node totals and export membership. All14 have no image/texture/skin/animation
or extension payload. Carrier palette names/default opaque and double-sided materials
agree with the description. Fifty-three accepted source/export/resource fingerprints
match actual bytes. This does not reopen Blender or re-prove source/reexport equality.

T correctly separates the S06 5,108-triangle technical baseline from the S05 effect
comparator. R correctly gates missing six-block linked content, exact placement
manifest, integrated production population/codecs/animation, effects, named hardware,
telemetry and four graphical processes/views. R's provisional 64 pedestrian/32 live
car targets and retained/projectile/cosmetic limits match design; missing content
counts are intentionally unset, not invented. G is conditional on R implicating
static placement/submission work: fixed bounds/variety/population, N→2N, distinct
saved identities and affected collision/topology validation, no4× or matrix. Budgets
are finite (T12/R18/G12 measured runs), with the existing immediate correctness stop,
growth stop, last-pass/first-fail and bounded noisy-rerun method. All cards remain
unexecuted and confer no runtime authorization or configuration/capacity verdict.

Candidate diff has precisely17 authorized files. All3,419 original non-TODO blobs
are identical to base, covering original fixtures/resources/sources/vendor/pins and
contracts. TODO has only the single evidence-link addition within S07; all27
unfinished task identities and other TODO bytes are preserved. Local links/anchors
pass. Candidate evidence expected-set exactly equals manifest payload keys; actual
directory/external payload equality, committed readback, lengths and SHA256 pass for
all16 payloads plus the self-excluded manifest. Empty retained stderr files are real
zero-byte streams. package.py was read and independently checked, never executed
because it writes the repository manifest.

## Actual checks and diagnostics

Actual sources are retained under `sources/` and bound to exact Git blobs/SHA256 in
`source-locators.json`. Reviewer checks/harness sources are retained beside this
report. Every recorded command has its real argv/cwd/exit and separate full stdout
and stderr under `checks/`, including empty streams. Large readback logs were saved
in full before tool-display truncation; no stored stream was shortened.

- `python3 tools/s07/inventory.py --output /tmp/s07-independent-review/reproduced-inventory.json`:
  exit0; reproduced JSON retained and byte-compared by the independent static check.
- `python3 docs/spikes/s07-run-card-evidence/validate.py --base 48aef3dbd133876743f504f94a1b788a26d5638f`:
  exit0; literal placements, hashes, camera overrides, historical finite ENet readback,
  27 local links/anchors, syntax, whitespace, TODO and scoped diff pass.
- `python3 /tmp/s07-independent-review/independent_static.py`: exit0; exact candidate/
  base, clean status, complete package/set/hash/readback, original blobs/task identities
  and independent binary GLB schema/index/membership checks pass.
- `python3 /tmp/s07-independent-review/final_checks.py`: exit0; accepted fingerprints,
  actual check-source retention and unchanged clean exact HEAD pass.
- Full contract, TODO-history, raw-input, saved-scene, package, accepted-evidence and
  numbered route readbacks: exit0. The retained source-search command exited2 because
  the reviewer initially guessed nonexistent `tests/fixtures/s02/movement_rules.gd`.
  Its stdout/stderr are retained; the actual `actor_motion.gd` was then read directly.
  This is a reviewer search error, not a candidate diagnostic or passing check.

## Limits and completion steering

No engine/Blender invocation, import/reexport, runtime suite, graphical observation,
hardware/service discovery, benchmark, optimization or configuration change occurred.
No runtime/API acceptance, DRAW, transformed world-AABB, imported generated LOD,
memory/residency, sustained performance, four-view, Deck/Steam or production evidence
is inferred. The helper is deliberately a fixed saved-subset text/metadata resolver;
it is not a generic Godot semantic/import/dependency validator. Its arbitrary script
literals, vendor-recursion stop, runtime material/spawn exclusions and mesh-local
bound limitations are appropriately disclosed. The P2 reset finding is a static
API/control-flow conclusion, not a newly executed runtime failure.

Repository remained clean at the exact candidate/base; writer idle was supplied by
the commission. No merge/archive/push/checkpoint or repository edit was performed.
After a material fix, the same reviewer must give compact exact-new-HEAD/base/delta
disposition; this REQUEST CHANGES does not approve a later candidate.

Deferred-pause user steering: lead1552576d should finish only necessary finding fixes,
same-reviewer final disposition, evidence retention and final handoff, then remain
idle. Start no new workstream or broader audit. ROOT finishes existing deliveries
and pauses. Forward this direction with the review completion notification.

Retention boundary: the user-named `/tmp/s07-independent-review` already contained
unrelated older capability-research files. Initial full-directory expected-set
validation rejected those unexpected paths (exit1); its actual complete stdout/
stderr and argv/exit are retained as `checks/retention-initial-failure.*`. No old
file was deleted, read as current-review evidence, or claimed as new research.
Only the explicitly enumerated current-review files were moved into
`/tmp/s07-independent-review/review-cdc5d0fa/`, which is this report's evidence root.
Checks ran at the original argv paths recorded in their logs; their actual sources
and outputs are retained unchanged here. Final packaging uses this private subtree's
explicit set and complete source/readback hashes. Retention failures are unrelated
to the candidate or the P2 finding and are preserved rather than suppressed.
The metadata-inclusive repeat of packaging then rejected its own existing manifest
(exit1, `checks/retention-metadata-failure.*`); the pre-fix actual script is retained.
The corrected source excludes only the declared self-excluded manifest on initial
enumeration and includes it in final directory equality. Final complete readback
passes for80 payloads plus that manifest. This changes reviewer retention only.
