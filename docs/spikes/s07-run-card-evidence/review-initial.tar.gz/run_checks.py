import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path('/tmp/s07-independent-review')
REPO = pathlib.Path('/home/regner/.paseo/worktrees/0u71f39f/s07-content-inventory-run-cards')

def run(name, argv):
    result = subprocess.run(argv, cwd=REPO, capture_output=True)
    (ROOT / 'checks' / (name + '.stdout')).write_bytes(result.stdout)
    (ROOT / 'checks' / (name + '.stderr')).write_bytes(result.stderr)
    record = {'argv': argv, 'cwd': str(REPO), 'exit': result.returncode}
    (ROOT / 'checks' / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(name, 'exit', result.returncode)
    sys.stdout.buffer.write(result.stdout)
    sys.stderr.buffer.write(result.stderr)
    return result

if __name__ == '__main__':
    run(sys.argv[1], sys.argv[2:])
