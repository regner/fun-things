import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = ['identity','contracts','cards','check-source','inputs-docs','inventory','validate',
          'todo-history','asset-contracts','spike-contracts','package-files','saved-files',
          'independent','accepted-source-records','source-search-failure','remaining-inputs',
          'route-repeat-evidence','final-static','retention-initial-failure','retention-final']
sources = ['tools/s07/inventory.py','docs/spikes/s07-run-card-evidence/validate.py',
           'docs/spikes/s07-run-card-evidence/package.py','tools/check.py',
           'tools/s06/check_resources.py','tools/s05_effect/check_resources.py']
expected = {'run_checks.py','independent_static.py','final_checks.py','retain.py',
            'report.md','effective-settings.json','reproduced-inventory.json',
            'source-locators.json','expected-set.json','sources/retention-initial.py'}
expected.update('sources/'+p for p in sources)
expected.update('checks/'+name+'.'+suffix for name in checks for suffix in ['json','stdout','stderr'])
(ROOT/'expected-set.json').write_text(json.dumps(sorted(expected),indent=2)+'\n')
actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
assert actual == expected, (sorted(expected-actual), sorted(actual-expected))
source_bytes = {p:(ROOT/p).read_bytes() for p in expected}
rows = {p:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        for p,data in source_bytes.items()}
(ROOT/'manifest.json').write_text(json.dumps({'self_excluded':True,'payloads':rows},indent=2,sort_keys=True)+'\n')
readback = json.loads((ROOT/'manifest.json').read_bytes())
assert set(readback['payloads']) == expected
for p,row in readback['payloads'].items():
    data=(ROOT/p).read_bytes()
    assert data == source_bytes[p]
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
assert {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()} == expected | {'manifest.json'}
print('PASS reviewer retention: explicit',len(expected),'payloads, full expected-set/readback/hash equality; manifest self-excluded')
