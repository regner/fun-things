import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path('/home/regner/.paseo/worktrees/0u71f39f/s07-content-inventory-run-cards')
OUT = Path('/tmp/s07-independent-review')
records = ['docs/spikes/s02-evidence/fingerprints.json',
           'docs/spikes/s04-evidence/reexport/fingerprints.json',
           'docs/spikes/s06-evidence/final-source-fingerprints.json']
count = 0
for record in records:
    for path, expected in json.loads((REPO / record).read_bytes()).items():
        assert hashlib.sha256((REPO / path).read_bytes()).hexdigest() == expected, path
        count += 1
effect = json.loads((REPO / 'docs/spikes/s05-effect-preparation-evidence/fingerprints.json').read_bytes())
for key in ['source', 'export']:
    data = (REPO / effect[key]).read_bytes()
    assert len(data) == effect[key+'_bytes']
    assert hashlib.sha256(data).hexdigest() == effect[key+'_sha256']
    count += 1
paths = ['tools/s07/inventory.py', 'docs/spikes/s07-run-card-evidence/validate.py',
         'docs/spikes/s07-run-card-evidence/package.py', 'tools/check.py',
         'tools/s06/check_resources.py', 'tools/s05_effect/check_resources.py']
rows = {}
for path in paths:
    data = (REPO / path).read_bytes()
    target = OUT / 'sources' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    assert target.read_bytes() == data
    rows[path] = {'candidate': '1ba0f189193f31d48ab39c3c3fc4e555089fc48b',
                  'git_blob': subprocess.check_output(['git','rev-parse','HEAD:'+path],cwd=REPO,text=True).strip(),
                  'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
(OUT / 'source-locators.json').write_text(json.dumps(rows,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip() == '1ba0f189193f31d48ab39c3c3fc4e555089fc48b'
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO)
print('PASS',count,'accepted source/export/resource fingerprints; six actual check sources retained; exact unchanged clean HEAD')
