import datetime, json, pathlib, subprocess
out = pathlib.Path('/tmp/s02-drawability')
host = subprocess.run(['python3', str(out/'inventory.py')], capture_output=True, check=True)
(out/'restore-host-before.stdout').write_bytes(host.stdout)
(out/'restore-host-before.stderr').write_bytes(host.stderr)
assert not json.loads(host.stdout)['authoring_processes'], 'HOST Godot/Blender must be absent'
main = '/home/regner/Development/fun-things'
argv = ['/home/regner/.local/share/mise/installs/github-godotengine-godot-builds/4.8-dev7/godot',
    '--editor', '--path', main, 'res://tests/fixtures/s04/editor_harness.tscn']
with (out/'restored-main.stdout').open('wb') as stdout, (out/'restored-main.stderr').open('wb') as stderr:
    child = subprocess.Popen(argv, cwd=main, stdout=stdout, stderr=stderr, start_new_session=True)
row = {'pid': child.pid, 'argv': argv, 'cwd': main,
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'purpose': 'one authorized saved main restoration; no experimental retry'}
(out/'main-restoration-launch.json').write_text(json.dumps(row, indent=2)+'\n')
print(json.dumps(row))
