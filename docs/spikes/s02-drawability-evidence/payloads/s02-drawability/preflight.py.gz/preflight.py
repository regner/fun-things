import json, pathlib, re
p = pathlib.Path('/tmp/s02-drawability')
host = json.loads((p / 'checks/preflight-host.stdout').read_text())
rows = host['authoring_processes']
assert len(rows) == 1 and rows[0]['pid'] == 426974
assert rows[0]['exe'] == '/home/regner/.local/share/mise/installs/github-godotengine-godot-builds/4.8-dev7/godot'
assert rows[0]['cwd'] == '/home/regner/Development/fun-things'
state = json.loads((p / 'checks/preflight-live.stdout').read_text())['response']['result']['result']
assert state['project'] == '/home/regner/Development/fun-things/'
assert state['pin']['hash'] == 'c971f93e7e76b0ef919bf6009e7b868bea04db7f'
assert state['unsaved'] == 'PackedStringArray()'
tabs = re.findall(r'"(res://[^\"]+)"', state['open'])
assert len(tabs) == 16 and len(set(tabs)) == 16
assert tabs[3] == 'res://tests/fixtures/s04/editor_harness.tscn'
(p / 'saved-tabs.json').write_text(json.dumps(tabs, indent=2) + '\n')
print(json.dumps({'verified': True, 'tabs': tabs, 'host_pid': 426974}))
