import hashlib, json, pathlib, re, struct
p = pathlib.Path('/tmp/s02-drawability'); o = pathlib.Path('/tmp/s02-drawability-observation')
before = json.loads((p/'bytes-before.json').read_text()); after = json.loads((p/'bytes-after.json').read_text())
assert before == after, 'per-checkout bytes/UIDs/status changed'
rows = [json.loads(line) for line in (p/'checks/main-refresh-reopen.stdout').read_text().splitlines()]
assert len(rows) == 51 and all('result' in row['response'] for row in rows)
assert all(row['response']['result'].get('success', False) for row in rows)
closes = [row['response']['result'] for row in rows if row['method']=='scene.close']
assert len(closes) == 16 and all(row['unsaved_changes_discarded'] is False for row in closes)
state = rows[-1]['response']['result']['result']
assert state['project']=='/home/regner/Development/fun-things/' and state['unsaved']=='PackedStringArray()'
assert state['pin']['hash']=='c971f93e7e76b0ef919bf6009e7b868bea04db7f'
tabs = re.findall(r'"(res://[^\"]+)"', state['open'])
assert tabs == json.loads((p/'saved-tabs.json').read_text())
host = json.loads((p/'checks/restoration-host.stdout').read_text())
launch = json.loads((p/'main-restoration-launch.json').read_text())
assert len(host['authoring_processes']) == 1 and host['authoring_processes'][0]['pid']==launch['pid']
assert host['authoring_processes'][0]['cwd']=='/home/regner/Development/fun-things'
frames = [json.loads(line) for line in (o/'receipts.jsonl').read_text().splitlines() if json.loads(line)['event']=='automatic_post_draw']
assert len(frames)==3 and [f['frames_drawn'] for f in frames]==[0,1,2]
assert frames[0]['monotonic_ms'] < frames[1]['monotonic_ms'] < frames[2]['monotonic_ms']
assert all(f['display']=='Wayland' and f['renderer']=='forward_plus' for f in frames)
assert all(f['camera_current'] and f['viewport_camera_matches'] for f in frames)
assert all(f['fov']==42 and f['camera_height']==47 and f['far']==160 and abs(f['near']-.1)<1e-6 for f in frames)
assert all(f['can_draw'] is False and f['viewport_size']==[2112,1320] for f in frames)
png = (o/'frame.png').read_bytes()
assert png[:8] == b'\x89PNG\r\n\x1a\n'
assert struct.unpack('>II', png[16:24]) == (2112,1320)
summary = json.loads((o/'summary.json').read_text())
assert summary['import']['exit']==0 and summary['runtime']['exit']==0
assert not summary['runtime']['cleanup_actions'] and summary['dependencies_unchanged_after_runtime']
log_paths = [o/'import.stdout',o/'import.stderr',o/'import.engine.log',o/'runtime.stdout',o/'runtime.stderr',o/'runtime.engine.log',p/'restored-main.stdout',p/'restored-main.stderr']
diagnostics = {str(f):[line for line in f.read_text(errors='replace').splitlines() if re.search(r'ERROR|WARNING|SCRIPT ERROR|crash|backtrace|deprecated|Method not found',line,re.I)] for f in log_paths}
runtime_clean = all(not diagnostics[str(f)] for f in log_paths[:6])
assert runtime_clean
main_root,work_root = list(before)
differences = [name for name,digest in before[main_root]['physical_sha256'].items() if name in before[work_root]['physical_sha256'] and digest!=before[work_root]['physical_sha256'][name]]
result = {'predeclared_positive_criteria':False, 'automatic_receipts':3,
    'receipt_frames':[0,1,2], 'receipt_ms':[f['monotonic_ms'] for f in frames],
    'can_draw':False, 'actual_image_size':[2112,1320], 'image_sha256':hashlib.sha256((o/'frame.png').read_bytes()).hexdigest(),
    'saved_camera_parameters_match':True, 'runtime_logs_clean':runtime_clean,
    'negative_reasons':['window_can_draw=false','actual viewport/PNG2112x1320 rather than predeclared1280x800'],
    'no_experimental_retry':True, 'restored_main_pid':launch['pid'], 'saved_tabs_preserved':tabs,
    'no_unsaved_work_discarded':True, 'per_checkout_bytes_and_saved_identities_stable':True,
    'tracked_counts':{root:len(data['physical_sha256']) for root,data in before.items()},
    'preexisting_cross_checkout_differences_preserved':differences,
    'log_diagnostics':diagnostics, 'operational_lease':'saved/quiescent; returned to root after this receipt',
    'remaining_limit':'automatic engine drawing/pixels observed, but native drawable status and exact viewport criteria failed; no interaction or scanout acceptance'}
(p/'postflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['saved_tabs_preserved','log_diagnostics','preexisting_cross_checkout_differences_preserved']},indent=2))
print(json.dumps({'cross_checkout_differences':differences, 'restored_editor_diagnostic_lines':diagnostics[str(p/'restored-main.stdout')]+diagnostics[str(p/'restored-main.stderr')]},indent=2))
