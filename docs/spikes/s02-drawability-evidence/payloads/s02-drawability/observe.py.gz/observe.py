import datetime, hashlib, json, os, pathlib, re, signal, subprocess, time

OUT = pathlib.Path('/tmp/s02-drawability-observation')
assert not OUT.exists(), 'fresh output required'
OUT.mkdir()
ROOT = pathlib.Path('/home/regner/.paseo/worktrees/0u71f39f/s02-drawability-evidence-path')
BASE = '4169a4466e01fb50acd8069308fc2556d03e0198'
BIN = '/home/regner/.local/share/mise/installs/github-godotengine-godot-builds/4.8-dev7/godot'
assert hashlib.sha256(pathlib.Path(BIN).read_bytes()).hexdigest() == '6aea356032435e7af19dbfbf48dd20c5012a7dc1267eb8e92406f44e3584b5fd'

def inventory(label):
    p = subprocess.run(['python3', '/tmp/s02-drawability/inventory.py'], capture_output=True)
    (OUT / (label + '.stdout')).write_bytes(p.stdout)
    (OUT / (label + '.stderr')).write_bytes(p.stderr)
    assert p.returncode == 0
    data = json.loads(p.stdout)
    assert not data['authoring_processes'], data['authoring_processes']
    return data

def run(label, argv, env, cap):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT / (label + '.stdout')).open('wb') as stdout, (OUT / (label + '.stderr')).open('wb') as stderr:
        child = subprocess.Popen(argv, cwd=OUT, env=env, stdout=stdout, stderr=stderr)
        pid = child.pid
        proc = pathlib.Path('/proc') / str(pid)
        identity = {'pid': pid, 'argv': argv, 'starttime_ticks': proc.joinpath('stat').read_text().split(') ')[1].split()[19]}
        actions = []
        try: code = child.wait(timeout=cap)
        except subprocess.TimeoutExpired:
            actions.append('supervisor deadline; SIGTERM exact owned Popen child')
            child.terminate()
            try: code = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                actions.append('owned-child SIGKILL after five-second termination deadline')
                child.kill(); code = child.wait(timeout=5)
    result = {**identity, 'cwd': str(OUT), 'started_utc': started,
        'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit': code,
        'cap_seconds': cap, 'cleanup_actions': actions,
        'private_environment': {k: env[k] for k in ['XDG_DATA_HOME', 'XDG_CONFIG_HOME', 'XDG_CACHE_HOME']}}
    (OUT / (label + '.command.json')).write_text(json.dumps(result, indent=2) + '\n')
    return result

inventory('host-before-preparation')
preparation_start = time.monotonic()
project = OUT / 'project'; project.mkdir()
pending = ['tests/fixtures/s02/corner.tscn']; copied = {}
while pending:
    path = pending.pop()
    if path in copied: continue
    data = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
    target = project / path; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
    copied[path] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
        'blob': subprocess.check_output(['git', 'rev-parse', BASE + ':' + path], cwd=ROOT).decode().strip()}
    if path.endswith(('.tscn', '.tres', '.gd', '.gdshader')):
        pending += re.findall(r'res://([^"\s\)]+)', data.decode())
    if path.endswith('.gd'): pending.append(path + '.uid')
    if path.endswith('.glb'): pending.append(path + '.import')
settings = subprocess.check_output(['git', 'show', BASE + ':project.godot'], cwd=ROOT).decode()
for section in ['autoload', 'editor_plugins']:
    settings = re.sub(r'(?ms)^\[' + section + r'\]\n.*?(?=^\[|\Z)', '', settings)
(project / 'project.godot').write_text(settings)
(project / 'icon.svg').write_bytes(subprocess.check_output(['git', 'show', BASE + ':icon.svg'], cwd=ROOT))
(project / 'addons').mkdir(); (project / 'addons/.gdignore').touch()
observer = pathlib.Path('/tmp/s02-drawability/observer.gd.txt').read_bytes()
(project / 'drawability_observer.gd').write_bytes(observer)
(OUT / 'observer.gd.txt').write_bytes(observer)
(OUT / 'staged-project.godot.txt').write_bytes((project / 'project.godot').read_bytes())
(OUT / 'source-manifest.json').write_text(json.dumps({'base': BASE, 'copied_dependencies': copied,
    'observer_sha256': hashlib.sha256(observer).hexdigest(),
    'only_project_exclusions': ['autoload', 'editor_plugins']}, indent=2) + '\n')
env = os.environ.copy()
for key, folder in [('XDG_DATA_HOME','data'), ('XDG_CONFIG_HOME','config'), ('XDG_CACHE_HOME','cache')]:
    directory = OUT / 'user' / folder; directory.mkdir(parents=True); env[key] = str(directory)
env['S02_DRAWABILITY_OUTPUT'] = str(OUT)
import_result = run('import', [BIN, '--headless', '--editor', '--path', str(project),
    '--import', '--quit', '--log-file', str(OUT / 'import.engine.log')], env,
    max(0.01, 90 - (time.monotonic() - preparation_start)))
unchanged = all(hashlib.sha256((project / path).read_bytes()).hexdigest() == v['sha256'] for path,v in copied.items())
logs = ''.join(p.read_text(errors='replace') for p in [OUT/'import.stdout', OUT/'import.stderr', OUT/'import.engine.log'] if p.exists())
summary = {'import': import_result, 'dependencies_unchanged_after_import': unchanged,
    'graphical_attempted': False, 'preparation_elapsed_seconds': time.monotonic() - preparation_start}
if import_result['exit'] == 0 and not import_result['cleanup_actions'] and unchanged and not re.search(r'(?m)^(?:SCRIPT ERROR|ERROR):', logs):
    inventory('host-before-runtime')
    summary['graphical_attempted'] = True
    summary['runtime'] = run('runtime', [BIN, '--path', str(project), '--display-driver', 'wayland',
        '--resolution', '1280x800', '--script', 'res://drawability_observer.gd',
        '--log-file', str(OUT/'runtime.engine.log')], env, 30)
    rows = [json.loads(line.removeprefix('S02_DRAWABILITY ')) for line in (OUT/'runtime.stdout').read_text().splitlines() if line.startswith('S02_DRAWABILITY ')]
    (OUT / 'receipts.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in rows))
    summary['automatic_receipts'] = sum(row['event']=='automatic_post_draw' for row in rows)
    summary['dependencies_unchanged_after_runtime'] = all(hashlib.sha256((project/path).read_bytes()).hexdigest()==v['sha256'] for path,v in copied.items())
else: summary['stop_reason'] = 'single preparation failed; no graphical launch authorized after failure'
inventory('host-after-observation')
(OUT/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
