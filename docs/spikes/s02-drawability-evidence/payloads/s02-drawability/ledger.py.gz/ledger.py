import hashlib, json, pathlib, re, subprocess, sys
roots = ['/home/regner/Development/fun-things',
    '/home/regner/.paseo/worktrees/0u71f39f/s02-drawability-evidence-path']
result = {}
for name in roots:
    root = pathlib.Path(name)
    status = subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root).decode()
    assert not status, (name, status)
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
    hashes = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths if p}
    resources = {}
    for p in hashes:
        if p.endswith(('.tscn', '.tres', '.uid', '.import')):
            text = (root / p).read_text()
            resources[p] = {'uid_values': re.findall(r'uid://[A-Za-z0-9]+', text),
                'identity_blocks': re.findall(r'\[(?:node|ext_resource|sub_resource)[^\]]+\]', text)}
    result[name] = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(),
        'status': status, 'physical_sha256': hashes, 'saved_identity_ledger': resources}
pathlib.Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({r: {'head': v['head'], 'tracked_files': len(v['physical_sha256']),
    'resource_entries': len(v['saved_identity_ledger']), 'clean': True} for r, v in result.items()}))
