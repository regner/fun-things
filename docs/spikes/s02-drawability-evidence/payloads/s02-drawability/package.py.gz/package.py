import gzip,hashlib,json,pathlib,shutil
ROOT=pathlib.Path('docs/spikes/s02-drawability-evidence');ROOT.mkdir(exist_ok=True)
P=pathlib.Path('/tmp/s02-drawability');manifest=json.loads((P/'operations-manifest.json').read_text())
paths=[pathlib.Path(x) for x in manifest['expected_payload_paths']+manifest['expected_index_paths']]
paths += [P/x for x in ['retain-operations.py','source-refs.py','source-refs.json','worker-identity.json','mcp__paseo__list_profiles.json','mcp__paseo__list_providers.json','mcp__paseo__list_models.json','package.py']]
for label in ['operation-retention','immutable-source-refs','immutable-source-refs-complete']:
 paths += [P/'checks'/f'{label}.{s}' for s in ['command.json','stdout','stderr']]
# Immutable snapshots of every named operational payload; no scratch project/cache/user directories.
rows=[]
for p in paths:
 b=p.read_bytes()
 if str(p)=='/tmp/s02-drawability-observation/frame.png':rel='frame.png';stored=b;codec='raw'
 else:rel='payloads/'+str(p.relative_to('/tmp'))+'.gz';stored=gzip.compress(b,mtime=0);codec='gzip; mtime=0'
 target=ROOT/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(stored)
 rows.append({'source_path':str(p),'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'codec':codec,'stored_bytes':len(stored),'stored_sha256':hashlib.sha256(stored).hexdigest()})
(ROOT/'.gdignore').touch()
(ROOT/'README.md').write_text('''# S02 single native Wayland observation evidence

This is a stopped operational experiment under S02, with saved main restoration.
See [the record](../s02-drawability.md) and the full raw commission/grant in the
indexed payloads. No further runtime operation is authorized by this evidence.

`manifest.json` lists every raw source path, retained path, decoded and stored SHA256,
and explicit complete expected payload/index sets, including zero-byte streams.
`readback.json` records actual decompression and source-byte/hash verification.
Text payloads use lossless gzip, mtime0; `gzip -dc <path>` reads complete content.
[frame.png](frame.png) is the third automatic callback's unchanged viewport PNG.

The operation manifest/readback, full command argv/exits/stdout/stderr, historical
failed checker versions, engine logs, pre/post byte and identity ledgers, saved-tab
queries, main restoration and management enumeration are retained in `payloads/`.
The live editor streams are immutable snapshots at the returned operational boundary;
the restored main editor remains root-owned, so this is not an editor exit claim.

`source-refs.json.gz` references complete retained prior evidence/reports by exact
reachable Git revision/blob, SHA256 and decoded note report locator. Read those
complete objects via `git show REV:PATH` or `git cat-file blob NOTE_BLOB`; historical
plain notes remain plain, while JSON report payloads are decoded according to their
stored codec. No recursive old-note/source-tree copies are introduced.

The predeclared protocol is immutable commit2a048901b69064b52a223f2c43fa69527620ac45.
Independent substantive/final reports, actual checks and exact-final readback will
be retained with the delivered same-HEAD JSON Git note in `refs/notes/paseo-orchestration`.
Neither engine callbacks nor an image close input/focus/feel/effects/capacity/device,
export/Steam/Deck/P0/M1/production gates.
''')
for rel in ['README.md','.gdignore']:
 b=(ROOT/rel).read_bytes();rows.append({'source_path':'authored:'+rel,'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'codec':'raw','stored_bytes':len(b),'stored_sha256':hashlib.sha256(b).hexdigest()})
indices=['manifest.json','readback.json']
result={'schema':'s02-drawability-retention-v1','base':manifest['base'],'protocol_commit':manifest['protocol_commit'],'expected_payload_paths':sorted(x['path'] for x in rows),'expected_index_paths':indices,'artifacts':rows}
(ROOT/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
for r in rows:
 raw=(ROOT/r['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['stored_sha256']
 decoded=gzip.decompress(raw) if r['codec'].startswith('gzip') else raw
 assert len(decoded)==r['bytes'] and hashlib.sha256(decoded).hexdigest()==r['sha256']
 if not r['source_path'].startswith('authored:'):assert decoded==pathlib.Path(r['source_path']).read_bytes()
actual={str(x.relative_to(ROOT)) for x in ROOT.rglob('*') if x.is_file()}
assert actual-set(indices)==set(result['expected_payload_paths']),(actual-set(indices))^set(result['expected_payload_paths'])
receipt={'decoded_and_stored_payloads_verified':len(rows),'expected_payload_set_verified':True,'expected_index_paths':indices,'empty_stream_paths':[x['path'] for x in rows if x['bytes']==0],'manifest_sha256':hashlib.sha256((ROOT/'manifest.json').read_bytes()).hexdigest(),'source_bytes_verified':True}
(ROOT/'readback.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert {str(x.relative_to(ROOT)) for x in ROOT.rglob('*') if x.is_file()}==set(result['expected_payload_paths']+indices)
print(json.dumps(receipt,indent=2))
