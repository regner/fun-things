import datetime, json, os, pathlib
root='/home/regner/.paseo/worktrees/0u71f39f/s02-drawability-evidence-path'
rows=[]
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdecimal():continue
    try:
        cwd=os.readlink(p/'cwd')
        if cwd!=root and not cwd.startswith(root+'/'):continue
        rows.append({'pid':int(p.name),'cwd':cwd,'exe':os.readlink(p/'exe'),
            'comm':(p/'comm').read_text().strip()})
    except OSError:continue
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'pid_namespace':os.readlink('/proc/self/ns/pid'), 'worktree_cwd_references':rows,
    'action':'enumeration only; no process signalled; root Paseo lifecycle owns managed references'},indent=2))
