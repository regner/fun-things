import datetime, hashlib, json, os, pathlib, shutil, subprocess
rows = []
displays = []
for proc in pathlib.Path('/proc').iterdir():
    if not proc.name.isdecimal(): continue
    try:
        exe = os.readlink(proc / 'exe')
        name = pathlib.Path(exe).name.lower()
        if not any(x in name for x in ['godot', 'blender', 'xorg', 'xwayland',
            'kwin', 'weston', 'sway', 'wayfire', 'gnome-shell', 'xvfb']): continue
        row = {'pid': int(proc.name), 'exe': exe, 'cwd': os.readlink(proc / 'cwd'),
            'argv': (proc / 'cmdline').read_bytes().decode().strip('\0').split('\0'),
            'starttime_ticks': (proc / 'stat').read_text().split(') ')[1].split()[19]}
        env = dict(x.split('=', 1) for x in (proc / 'environ').read_bytes().decode().split('\0') if '=' in x)
        row['display_environment'] = {k: env[k] for k in ['DISPLAY', 'WAYLAND_DISPLAY',
            'XDG_SESSION_TYPE', 'XDG_RUNTIME_DIR'] if k in env}
        if 'godot' in name or 'blender' in name:
            if 'godot' in name: row['binary_sha256'] = hashlib.sha256(pathlib.Path(exe).read_bytes()).hexdigest()
            rows.append(row)
        else: displays.append(row)
    except (OSError, ValueError, IndexError): continue
result = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'pid_namespace': os.readlink('/proc/self/ns/pid'),
    'net_namespace': os.readlink('/proc/self/ns/net'), 'authoring_processes': rows,
    'display_processes': displays,
    'caller_display': {k: os.environ[k] for k in ['DISPLAY', 'WAYLAND_DISPLAY',
        'XDG_SESSION_TYPE', 'XDG_RUNTIME_DIR'] if k in os.environ},
    'read_only_utilities': {k: shutil.which(k) for k in ['xprop', 'xrandr', 'wayland-info']}}
print(json.dumps(result, indent=2))
