import hashlib, json, pathlib
p=pathlib.Path('/tmp/s02-drawability');o=pathlib.Path('/tmp/s02-drawability-observation')
labels=['host-inventory','main-saved-state','wayland-interfaces','binary-capability',
    'preflight-host','preflight-live','preflight-check','bytes-before','main-graceful-quit',
    'host-after-main-quit','single-observation','main-restoration-launch',
    'restored-initial-state','main-refresh-reopen','restoration-host','bytes-after',
    'operational-postflight','managed-cwd-refs','operational-postflight-fixed',
    'operational-postflight-prefix']
expected=[p/'checks'/f'{label}.{suffix}' for label in labels for suffix in ['command.json','stdout','stderr']]
expected += [p/name for name in ['capture.py','inventory.py','binary-capability.py',
    'main-state-request.json','ledger.py','preflight.py','quit-request.json','observer.gd.txt',
    'observe.py','restore-main.py','restore-requests.json','postflight.py',
    'postflight-before-png-header.py','postflight-before-diagnostic-prefix.py','cwd-refs.py',
    'saved-tabs.json','bytes-before.json','bytes-after.json','postflight.json',
    'main-restoration-launch.json','restore-host-before.stdout','restore-host-before.stderr',
    'restored-main.stdout','restored-main.stderr','raw-requirements.txt','raw-grant.txt']]
expected += [o/name for name in ['host-before-preparation.stdout','host-before-preparation.stderr',
    'host-before-runtime.stdout','host-before-runtime.stderr','host-after-observation.stdout',
    'host-after-observation.stderr','import.stdout','import.stderr','import.engine.log',
    'import.command.json','runtime.stdout','runtime.stderr','runtime.engine.log','runtime.command.json',
    'receipts.jsonl','frame.png','observer.gd.txt','staged-project.godot.txt','source-manifest.json','summary.json']]
assert len(expected)==len(set(expected))
entries=[]
for path in expected:
    data=path.read_bytes();entries.append({'source_path':str(path),'bytes':len(data),
        'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':'s02-drawability-operation-manifest-v1',
    'protocol_commit':'2a048901b69064b52a223f2c43fa69527620ac45',
    'base':'4169a4466e01fb50acd8069308fc2556d03e0198',
    'expected_payload_paths':[str(x) for x in expected],
    'expected_index_paths':[str(p/'operations-manifest.json'),str(p/'operations-readback.json')],
    'artifacts':entries}
(p/'operations-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
actual=json.loads((p/'operations-manifest.json').read_text())
assert actual==manifest
for row in actual['artifacts']:
    data=pathlib.Path(row['source_path']).read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt={'payloads_verified':len(entries),'manifest_sha256':hashlib.sha256((p/'operations-manifest.json').read_bytes()).hexdigest(),
    'expected_payload_set_verified':True,'expected_index_paths':manifest['expected_index_paths'],
    'empty_streams':[row['source_path'] for row in entries if row['bytes']==0],
    'scope':'operation boundary sealed; both index files later included in final retention expected set'}
(p/'operations-readback.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
