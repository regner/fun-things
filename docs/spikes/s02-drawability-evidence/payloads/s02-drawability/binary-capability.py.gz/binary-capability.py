import hashlib, json, pathlib, re
p = pathlib.Path('/home/regner/.local/share/mise/installs/github-godotengine-godot-builds/4.8-dev7/godot')
b = p.read_bytes()
needles = [b'--display-driver', b'DisplayServerWayland', b'wayland', b'xdg_wm_base',
    b'frame_post_draw', b'window_can_draw']
strings = re.findall(rb'[\x20-\x7e]{5,}', b)
result = {'binary': str(p), 'sha256': hashlib.sha256(b).hexdigest(),
    'strings_are_capability_evidence_not_launch_validation': True, 'matches': {}}
for needle in needles:
    matches = [s.decode() for s in strings if needle in s and len(s) < 300]
    result['matches'][needle.decode()] = matches[:20]
    result['matches'][needle.decode() + '_count'] = len(matches)
print(json.dumps(result, indent=2))
