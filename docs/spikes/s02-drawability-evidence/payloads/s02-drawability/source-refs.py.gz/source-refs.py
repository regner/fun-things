import base64,gzip,hashlib,json,pathlib,re,subprocess
BASE='4169a4466e01fb50acd8069308fc2556d03e0198'
def git(*args):return subprocess.check_output(['git',*args])
def digest(b):return hashlib.sha256(b).hexdigest()
paths=git('ls-tree','-r','--name-only',BASE).decode().splitlines()
selected=['AGENTS.md','.agents/skills/paseo-orchestrator/SKILL.md','.agents/skills/godot-mcp-toolkit/SKILL.md','TODO.md','project.godot','docs/reviews/plan-checkpoints.md','docs/reviews/plan-check-2026-10-08-07.md']
selected += [f'docs/spikes/{n}.md' for n in ['s02','s03-r','s04','s05','s06']]
selected += [p for p in paths if p.startswith('docs/reviews/s02-') or p.startswith('docs/reviews/s03-r-') or p=='docs/reviews/s04-10874476.md']
selected += ['tools/s02/capture_s02.gd','tools/s02/run.py','tools/s03_r/run.py','tools/s04/run.py','tools/s04/editor_probe.gd','docs/spikes/s05-evidence/review/report.md','docs/spikes/s06-evidence/operations/client.mjs']
selected += [p for p in paths if p.startswith('docs/spikes/s02-evidence/history/') and ('focus' in p or 'capture' in p)]
selected += ['docs/spikes/s02-evidence/os-focus.log','docs/spikes/s02-evidence/captures.log']
selected += [p for p in paths if p.startswith('docs/spikes/s03-r-evidence/') and ('graph' in p or 'failure' in p or 'render' in p or 'window' in p)]
selected += [p for p in paths if p.startswith('docs/spikes/s04-evidence/window-diagnosis/')]
# Actual S03-R graphical failures reside in runtime named directories, index exact logs.
selected += [p for p in paths if p.startswith('docs/spikes/s03-r-evidence/') and any(s in p for s in ['graphical','failed-graph','graphical-failure'])]
selected += [p for p in paths if p.startswith('docs/spikes/s03-r-evidence/failed-attempts/') and ('stdout' in p or 'technical-result' in p)]
selected += ['docs/spikes/s03-r-evidence/protocol-before-measurement.md','docs/spikes/s06-evidence/tool-diagnostic-history.json','docs/spikes/s06-evidence/operations/first-run.stdout']
refs=[]
for p in sorted(set(selected)):
 if p not in paths:continue
 b=git('show',BASE+':'+p);decoded=gzip.decompress(b) if p.endswith('.gz') else b
 refs.append({'revision':BASE,'path':p,'git_blob':git('rev-parse',BASE+':'+p).decode().strip(),'bytes':len(b),'sha256':digest(b),'decoded_bytes':len(decoded),'decoded_sha256':digest(decoded)})
notes=[]
for rev in ['ae48eb3dd498075bdd854119c5d124a8251dbbb1','2370ad1c182b46e51f5dc4c6b6ab6157819e84b0','754a0b501fe705c93675ff09b43d5bfca201cd94','7fb302ba2829966c9a687a12a7f00d09ce6a7824','64bd46bd760e66cb74ddb0638f26f8e75c5f52f2','4169a4466e01fb50acd8069308fc2556d03e0198']:
 git('merge-base','--is-ancestor',rev,BASE)
 blob=git('notes','--ref=paseo-orchestration','list',rev).decode().split()[0];b=git('cat-file','blob',blob)
 row={'annotated_revision':rev,'notes_commit':git('rev-parse','refs/notes/paseo-orchestration').decode().strip(),'note_blob':blob,'bytes':len(b),'sha256':digest(b),'format':'historical plain-text'}
 try:v=json.loads(b)
 except ValueError:notes.append(row);continue
 row['format']='strict JSON';reports=[]
 for key in ['payloads','artifacts']:
  for i,p in enumerate(v.get(key,[])):
   if 'report' not in str(p.get('source_path',p.get('name',''))):continue
   raw=base64.b64decode(p.get('data',p.get('data_base64',p.get('payload_base64',''))))
   if 'gzip' in str(p.get('codec',p.get('encoding',''))):raw=gzip.decompress(raw)
   if not raw:continue
   assert len(raw)==p['bytes'] and digest(raw)==p['sha256'],p
   reports.append({'json_locator':f'{key}[{i}]','source_path':p.get('source_path'),'bytes':len(raw),'sha256':digest(raw)})
 row['complete_report_payloads']=reports;notes.append(row)
result={'base':BASE,'immutable_git_sources':refs,'immutable_note_sources':notes,'policy':'Read complete referenced blobs/payloads; no recursive raw-old-note or source-tree copy.'}
pathlib.Path('/tmp/s02-drawability/source-refs.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source_refs':len(refs),'note_refs':len(notes),'complete_decoded_reports':sum(len(x.get('complete_report_payloads',[])) for x in notes)}))
