import datetime, json, pathlib, subprocess, sys
root = pathlib.Path('/tmp/s02-drawability/checks'); root.mkdir(exist_ok=True)
label, *argv = sys.argv[1:]
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
p = subprocess.run(argv, capture_output=True)
(root / (label + '.stdout')).write_bytes(p.stdout)
(root / (label + '.stderr')).write_bytes(p.stderr)
(root / (label + '.command.json')).write_text(json.dumps({'argv': argv,
    'cwd': str(pathlib.Path.cwd()), 'started_utc': start,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'exit': p.returncode}, indent=2) + '\n')
print(json.dumps({'label': label, 'exit': p.returncode, 'stdout_bytes': len(p.stdout),
    'stderr_bytes': len(p.stderr)}))
print(p.stdout.decode(errors='replace')); print(p.stderr.decode(errors='replace'))
sys.exit(p.returncode)
